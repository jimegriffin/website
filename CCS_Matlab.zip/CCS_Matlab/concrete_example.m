close all
addpath 'utils'

load('results_concrete.mat');

samples = storegamma;


close all

type = 2;
% type = 1 is thresholded correlation matrix
% type = 2 is likelihood ratio score
M = 2;
prob_level = 0.5;
% probability level for Cartesian credible set
threshold = 0.04;
% threshold for screening PIPs

load('results_concrete.mat');

[thresh, lograt, nodeToComponent, Conf_Set, prob_set] = find_CCS(storegamma, prob_level, threshold, type, M);
% thresh = the value of the algorithmic parameter eta
% lograt = the value of the ease-of-understanding penalized criterion
% nodeToComponent = a vector whose i-th entry is the block for the i-th
% variable
% Conf_Set = a cell whose i-th entry is a matrix containing the block
% credible set for the i-th block (each row is a sub-model)
% prob_set = a cell whose i-th entry is a vector giving the marginal PIP
% for each sub-model in the i-th block


figure(1)
plot(thresh, lograt);


figure(2)
load('AllVarNames_concrete.mat')
totalrows = plots_CCS(nodeToComponent, 1:size(storegamma, 2), Conf_Set, prob_set, AllVarNames, 13);



