function [x1, x2, score, complexity, Z] = find_uncorrelated2(samples, maxdepth)

n = size(samples, 1);

%cov1 = [1 0.8 0.01 0 0; 0.8 1 0 0 0; 0.01 0 1 0.8 0; 0 0 0.8 1 0; 0 0 0 0 1];
%cov1 = [1 0.8 0; 0.8 1 0; 0 0 1];

pdim = size(samples, 2);

x1 = cell(maxdepth, 1);
x2 = cell(maxdepth, 1);
Z = zeros(maxdepth - 1, 3);
score = zeros(maxdepth, 1);
complexity = zeros(maxdepth, 1);


[Au,~,ic] = unique(samples, 'rows');
nstar = accumarray(ic, 1);


for k = 1:size(Au, 1)
%    count = ones(n, 1);
%    for m = 1:size(gammastar, 2)
%        count = count .* (samples(:, m) == gammastar(k, m));
%    end
%    nstar = sum(count);

    score = score - nstar(k) / n * log(nstar(k) / n);
end

x1{1, 1} = cell(pdim, 1);
for i = 1:size(x1{1, 1}, 1)
    x1{1, 1}{i, 1} = i;
    x2{1, 1}(i) = i;

    xstar = x1{1, 1}{i, 1};
    %    gammastar = unique(samples(:, xstar), 'rows');

    [Au,~,ic] = unique(samples(:, xstar), 'rows');
    nstar = accumarray(ic, 1);


    for k = 1:size(Au, 1)
    %    count = ones(n, 1);
    %    for m = 1:size(gammastar, 2)
    %        count = count .* (samples(:, xstar(m)) == gammastar(k, m));
    %    end
     %   nstar = sum(count);

        score(1) = score(1) + nstar(k) / n * log(nstar(k) / n);
    end
end
complexity(1) = 1;

for i1 = 2:maxdepth

%        i1

%    pdim
%    maxdepth
%size(x1{i1 - 1, 1}, 1)

    dist = zeros(size(x1{i1 - 1, 1}, 1) * (size(x1{i1 - 1, 1}, 1) - 1) / 2, 1);
    dethold = 0;
    for i = 1:size(x1{i1 - 1, 1}, 1)
        xstar = x1{i1 - 1, 1}{i, 1};
        if ( i == 1 )
            c1 = length(xstar);
        elseif ( length(xstar) > c1 )
            c1 = length(xstar);
        end

        [Au,~,ic] = unique(samples(:, xstar), 'rows');
        nstar = accumarray(ic, 1);

%        gammastar = unique(samples(:, xstar), 'rows');
        for k = 1:size(Au, 1)
%            count = ones(n, 1);
 %           for m = 1:size(gammastar, 2)
  %              count = count .* (samples(:, xstar(m)) == gammastar(k, m));
   %         end
    %        nstar = sum(count);

            dethold = dethold + nstar(k) / n * log(nstar(k) / n);
        end
    end
    cdist = c1 * ones(size(x1{i1 - 1, 1}, 1) * (size(x1{i1 - 1, 1}, 1) - 1) / 2, 1);
    indhold = zeros(size(x1{i1 - 1, 1}, 1) * (size(x1{i1 - 1, 1}, 1) - 1) / 2, 2);
    indhold2 = zeros(size(x1{i1 - 1, 1}, 1) * (size(x1{i1 - 1, 1}, 1) - 1) / 2, 2);
    counter = 0;
    for i = 1:size(x1{i1 - 1, 1}, 1)
        for j = (i + 1):size(x1{i1 - 1, 1}, 1)

            counter = counter + 1;
            indhold(counter, :) = [i j];
            indhold2(counter, :) = [x2{i1 - 1, 1}(i) x2{i1 - 1, 1}(j)];
            xstar = [x1{i1 - 1, 1}{i, 1} x1{i1 - 1, 1}{j, 1}];
            if ( length(xstar) > c1 )
                cdist(counter) = length(xstar);
            end
            
            holdxstar = xstar;

            dist(counter) = dethold;

            [Au,~,ic] = unique(samples(:, xstar), 'rows');
            nstar = accumarray(ic, 1);


%            gammastar = unique(samples(:, xstar), 'rows');
            countstar = 0;
            for k = 1:size(Au, 1)
   %             count = ones(n, 1);
    %            for m = 1:size(gammastar, 2)
     %               count = count .* (samples(:, xstar(m)) == gammastar(k, m));
      %          end
       %         nstar = sum(count);
                dist(counter) = dist(counter) + nstar(k) * log(nstar(k) / n);
                countstar = countstar + nstar(k) / n * log(nstar(k) / n);
            end

            xstar = x1{i1 - 1, 1}{i, 1};
            [Au,~,ic] = unique(samples(:, xstar), 'rows');
            nstar = accumarray(ic, 1);

%            gammastar = unique(samples(:, xstar), 'rows');
            countstar = 0;
            for k = 1:size(Au, 1)
  %              count = ones(n, 1);
   %             for m = 1:size(gammastar, 2)
    %                count = count .* (samples(:, xstar(m)) == gammastar(k, m));
     %           end
      %          nstar = sum(count);
                dist(counter) = dist(counter) - nstar(k) * log(nstar(k) / n);
                countstar = countstar + nstar(k) * log(nstar(k) / n);
            end

            xstar = x1{i1 - 1, 1}{j, 1};
            [Au,~,ic] = unique(samples(:, xstar), 'rows');
            nstar = accumarray(ic, 1);
        %    gammastar = unique(samples(:, xstar), 'rows');
            countstar = 0;
            for k = 1:size(Au, 1)
         %       count = ones(n, 1);
      %          for m = 1:size(gammastar, 2)
       %             count = count .* (samples(:, xstar(m)) == gammastar(k, m));
        %        end
         %       nstar = sum(count);
                dist(counter) = dist(counter) - nstar(k) * log(nstar(k) / n);
                countstar = countstar + nstar(k) / n * log(nstar(k) / n);
            end
        end
    end

%    dist

    [m1, m2] = max(dist);
    score(i1) = m1;
    complexity(i1) = cdist(m2);

    Z(i1 - 1, :) = [indhold2(m2, 1) indhold2(m2, 2) -score(i1)];

    x1{i1, 1} = cell(pdim - i1 + 1, 1);
    x2{i1, 1} = zeros(pdim - i1 + 1, 1);
    counter = 0;
    for i = 1:(indhold(m2, 1) - 1)
        counter = counter + 1;
        x1{i1, 1}{counter, 1} = x1{i1 - 1, 1}{i, 1};
        x2{i1, 1}(counter) = x2{i1 - 1, 1}(i);
    end
    counter = counter + 1;
    x1{i1, 1}{counter, 1} = [x1{i1 - 1, 1}{indhold(m2, 1)} x1{i1 - 1, 1}{indhold(m2, 2), 1}];
    x2{i1, 1}(counter) = max(x2{i1 - 1, 1}) + 1;
    for i = (indhold(m2, 1) + 1):(indhold(m2, 2) - 1)
        counter = counter + 1;
        x1{i1, 1}{counter, 1} = x1{i1 - 1, 1}{i, 1};
        x2{i1, 1}(counter) = x2{i1 - 1, 1}(i);
    end
    for i = (indhold(m2, 2) + 1):size(x1{i1 - 1, 1}, 1)
        counter = counter + 1;
        x1{i1, 1}{counter, 1} = x1{i1 - 1, 1}{i, 1};
        x2{i1, 1}(counter) = x2{i1 - 1, 1}(i);
    end
end
