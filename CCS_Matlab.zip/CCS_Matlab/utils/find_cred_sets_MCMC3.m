function [nodeToComponent, Conf_Set, prob_set, set_size, score, complexity, x1] = find_cred_sets_MCMC3(samples, maxdepth, prob_level)

pdim = size(samples, 2);

PIP = mean(samples);

[x1, x2, score, complexity, Z] = find_uncorrelated2(samples, maxdepth);

nodeToComponent = zeros(1, pdim);
for i = 1:size(x1{maxdepth, 1}, 1)
    for j = 1:length(x1{maxdepth, 1}{i, 1})
        nodeToComponent(x1{maxdepth, 1}{i, 1}(j)) = i;
    end
end


%[Conf_Set, prob_set, set_size] = full_set_small(B2_store, params, prob_level);
[Conf_Set, prob_set, set_size] = backwards_small2_old(nodeToComponent, samples, prob_level);



