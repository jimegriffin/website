function [nodeToComponent, Conf_Set, prob_set, set_size, Corr1, Cov1] = find_cred_sets_MCMC2(samples, thresh, prob_level)

pdim = size(samples, 2);

PIP = mean(samples);
stand_dev = sqrt(PIP .* (1 - PIP));

Cov1 = zeros(pdim, pdim);
Corr1 = zeros(pdim, pdim);
for i = 1:pdim
    for j = 1:(i-1)
        Cov1(i, j) = abs((mean(samples(:, i) .* samples(:, j)) - PIP(i) * PIP(j)));
        Corr1(i, j) = abs((mean(samples(:, i) .* samples(:, j)) - PIP(i) * PIP(j))) / (stand_dev(i) * stand_dev(j));
        if ( isnan(Corr1(i, j)) == 1 )
            Corr1(i, j) = 0;
        end
    end
    Cov1(i, i) = stand_dev(i)^2;
end

mat1 = (Corr1 > thresh) .* Corr1;

xstar = [1 2 3 4 9 11 13 15];
%mat1(xstar, xstar)

G2 = graph(mat1, 'omitselfloops','lower');
nodeToComponent = conncomp(G2);

%nodeToComponent

%[Conf_Set, prob_set, set_size] = full_set_small(B2_store, params, prob_level);
[Conf_Set, prob_set, set_size] = backwards_small2_old(nodeToComponent, samples, prob_level);

%'here3'
