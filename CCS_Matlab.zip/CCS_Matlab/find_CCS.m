function [thresh, lograt, nodeToComponent, Conf_Set, prob_set] = find_CCS(samples, prob_level, threshold, type, M)

% type = 1 is thresholded correlation matrix
% type = 2 is likelihood ratio score

%pdim = size(samples, 2);

[samples, prob] = screened(samples, threshold);

if ( type == 1 )
    thresh = linspace(0.95, 0.01, 199);
else
    thresh = 1:size(samples, 2);
end
storesize = zeros(1, length(thresh));
storeDP = zeros(1, length(thresh));
lograt = zeros(1, length(thresh));

check = 0;
count = 0;
while ( check == 0 )
    count = count + 1;
    if ( type == 1 )
        [nodeToComponent, Conf_Set, prob_set, set_size, Corr1, Cov1] = find_cred_sets_MCMC2(samples, thresh(count), prob_level);
    end

    if ( type == 2 )
        [nodeToComponent, Conf_Set, prob_set, set_size, score, complexity, X1] = find_cred_sets_MCMC3(samples, count, prob_level);
    end

    for i = 1:length(Conf_Set)
        storesize(count) = storesize(count) + log(size(Conf_Set{1, i}, 1));
        storeDP(count) = storeDP(count) + log(M) + gammaln(sum(nodeToComponent == i));
    end
    lograt(count) = storesize(count) + storeDP(count);


    if (lograt(count) > 1.2 * min(lograt(1:count)))
        check = 1;
    elseif (count == length(thresh))
        check = 1;
    end
end
lograt = lograt(1:count);
thresh = thresh(1:count);

%lograt(lograt == 0) = max(lograt) + 100;

m1 = min(lograt);
count = find(lograt == m1, 1, 'first');

if ( type == 1 )
    [nodeToComponent, Conf_Set, prob_set, set_size, Corr1, Cov1] = find_cred_sets_MCMC2(samples, thresh(count), prob_level);
end

if ( type == 2 )
    [nodeToComponent, Conf_Set, prob_set, set_size, score, complexity, X1] = find_cred_sets_MCMC3(samples, thresh(count), prob_level);
end


