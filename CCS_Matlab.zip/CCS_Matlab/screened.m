function [screened_samples, prob] = screened(samples, threshold)

numbofits = size(samples, 1);

PIP = mean(samples);

screened_samples = samples(:, PIP > threshold);

check1 = sum(samples(:, PIP < threshold), 2);
prob = 1 - sum(check1 > 0) / numbofits;