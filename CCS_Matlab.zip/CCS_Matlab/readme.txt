The code are
screend - which removes columns from the output of the inclusion variables with PIPs below a user-defined threshold
find_CCS - which finds Cartesian credible sets from MCMC output
plots_CCS - which plots graphs of the Cartesian credible sets (as seen in the paper)

The file concerete_example.m is an example of using these functions with the concrete data sets from the paper (using Prior I). 