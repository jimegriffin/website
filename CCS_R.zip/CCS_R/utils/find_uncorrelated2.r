find_uncorrelated2 = function(samples, oldpartition1, i1) {
    
    n = dim(samples)[1]
    pdim = dim(samples)[2]

    dist = numeric(dim(oldpartition1)[1] * (dim(oldpartition1)[1] - 1) / 2)
    dethold = 0
    for (i in 1:dim(oldpartition1)[1]) {
        xstar = oldpartition1[[i, 1]]
        if ( i == 1 ) {
            c1 = length(xstar)
        } else if ( length(xstar) > c1 ) {
            c1 = length(xstar)
        }

        out = uniquecombs(as.matrix(samples[, xstar]))
        Au = out
        ic = attr(out, "index")
        nstar = as.numeric(table(ic))
    
        dethold = sum(nstar / n * log(nstar / n))
    }
    cdist = c1 * rep(1, dim(oldpartition1)[1] * (dim(oldpartition1)[1] - 1) / 2)
    indhold = matrix(0, dim(oldpartition1)[1] * (dim(oldpartition1)[1] - 1) / 2, 2)
    counter = 0
    for (i in 1:(dim(oldpartition1)[1]-1)) {
        for (j in (i + 1):dim(oldpartition1)[1]) {
            counter = counter + 1
            indhold[counter, ] = c(i, j)
            xstar = c(oldpartition1[[i, 1]], oldpartition1[[j, 1]])
            if ( length(xstar) > c1 ) {
                cdist[counter] = length(xstar)
            }
            
            holdxstar = xstar
            
            dist[counter] = dethold

            out = uniquecombs(as.matrix(samples[, xstar]))
            Au = as.matrix(out)
            if ( dim(Au)[2] != dim(as.matrix(samples[, xstar]))[2])
                Au = t(Au)
            ic = attr(out, "index")
            nstar = as.numeric(table(ic))
            dist[counter] = dist[counter] + sum(nstar / n * log(nstar / n))

            xstar = oldpartition1[[i, 1]]
            out = uniquecombs(as.matrix(samples[, xstar]))
            Au = as.matrix(out)
            if ( dim(Au)[2] != dim(as.matrix(samples[, xstar]))[2])
                Au = t(Au)
            ic = attr(out, "index")
            nstar = as.numeric(table(ic))
 
            dist[counter] = dist[counter] - sum(nstar / n * log(nstar / n))

            xstar = oldpartition1[[j, 1]]
            out = uniquecombs(as.matrix(samples[, xstar]))
            Au = as.matrix(out)
            if ( dim(Au)[2] != dim(as.matrix(samples[, xstar]))[2])
                Au = t(Au)

            ic = attr(out, "index")
            nstar = as.numeric(table(ic))
            dist[counter] = dist[counter] - sum(nstar / n * log(nstar / n))
 
            if (is.na(dist[counter]) == 1)
                stop()
        }
    }

    
    m1 = max(dist)
    m2 = which.max(dist)
                    
    partition1 = matrix(list(), pdim - i1 + 1, 1)
    counter = 0
    if ( indhold[m2, 1] > 1 ) {
        for (i in 1:(indhold[m2, 1] - 1)) {
            counter = counter + 1
            partition1[[counter, 1]] = oldpartition1[[i, 1]]
        }
    }
    
    counter = counter + 1
    partition1[[counter, 1]] = c(oldpartition1[[indhold[m2, 1]]], oldpartition1[[indhold[m2, 2], 1]])
    if ( indhold[m2, 2] - indhold[m2, 1] > 1) {
        for (i in (indhold[m2, 1] + 1):(indhold[m2, 2] - 1)) {
            counter = counter + 1
            partition1[[counter, 1]] = oldpartition1[[i, 1]]
        }
    }
    
    if ( indhold[m2, 2] < dim(oldpartition1)[1]) {
        for (i in (indhold[m2, 2] + 1):dim(oldpartition1)[1]) {
            counter = counter + 1
            partition1[[counter, 1]] = oldpartition1[[i, 1]]
        }
    }    
    
    list(partition1 = partition1)
}
