find_cred_sets_MCMC2 = function(samples, thresh, prob_level) {

    pdim = dim(samples)[2]

    PIP = colMeans(samples)
    stand_dev = sqrt(PIP * (1 - PIP))
    
    Cov1 = cov(samples)
    Corr1 = cor(samples)
    Corr1[is.na(Corr1)] = 0
    mat1 = (Corr1 > thresh)
    
    
    G2 = graph_from_adjacency_matrix(mat1, mode = 'undirected')
    nodeToComponent = components(G2)$membership

    out = backwards_small2_old(nodeToComponent, samples, prob_level)
    
    Conf_Set = out$Conf_Set
    prob_set = out$prob_set
    set_size = out$set_size

    list(nodeToComponent = nodeToComponent, Conf_Set = Conf_Set, prob_set = prob_set, set_size = set_size, Corr1 = Corr1, Cov1 = Cov1)
}
