find_cred_sets_MCMC3 = function(samples, maxdepth, prob_level) {
    
    thresh = 1:dim(samples)[2]
    maxdepth = dim(samples)[2]

    n = dim(samples)[1]
    pdim = dim(samples)[2]

    x1 = matrix(list(), maxdepth, 1)
    x2 = matrix(list(), maxdepth, 1)
    Conf_Set = matrix(list(), maxdepth, 1)
    prob_set = matrix(list(), maxdepth, 1)
    nodeToComponent = matrix(list(), maxdepth, 1)
    lograt = numeric(maxdepth)

    x1[[1, 1]] = matrix(list(), pdim, 1)
    for (i in 1:dim(x1[[1, 1]])[1]) {
        x1[[1, 1]][[i, 1]] = i
        x2[[1, 1]][i] = i
    }
    
    nodeToComponent[[1, 1]] = numeric(pdim)
    for (i in 1:dim(x1[[1, 1]])[1])
        for (j in 1:length(x1[[1, 1]][[i, 1]]))
            nodeToComponent[[1, 1]][x1[[1, 1]][[i, 1]][j]] = i

    out = backwards_small2_old(nodeToComponent[[1, 1]], samples, prob_level)
    Conf_Set[[1, 1]] = out$Conf_Set
    prob_set[[1, 1]] = out$prob_set
 
    storesize = 0
    storeDP = 0
    for (i in 1:length(Conf_Set[[1, 1]])) {
        storesize = storesize + log(dim(Conf_Set[[1, 1]][[1, i]])[1])
        storeDP = storeDP + log(M) + lgamma(sum(nodeToComponent[[1, 1]] == i))
    }
    lograt[1] = storesize + storeDP
    
    check = 0
    count = 1
    while ( check == 0 ) {
        count = count + 1
        print(count)
        out = find_uncorrelated2(samples, x1[[count - 1, 1]], x2[[count - 1, 1]], count)
        
        x1[[count, 1]] = out$x1
        x2[[count, 1]] = out$x2

        nodeToComponent[[1, 1]] = numeric(pdim)
        for (i in 1:dim(x1[[count, 1]])[1])
        for (j in 1:length(x1[[count, 1]][[i, 1]]))
            nodeToComponent[[count, 1]][x1[[count, 1]][[i, 1]][j]] = i

        out = backwards_small2_old(nodeToComponent[[count, 1]], samples, prob_level)

        Conf_Set[[count, 1]] = out$Conf_Set
        prob_set[[count, 1]] = out$prob_set
    
        storesize = 0
        storeDP = 0
        for (i in 1:length(Conf_Set[[count, 1]])) {
            storesize = storesize + log(dim(Conf_Set[[count, 1]][[1, i]])[1])
            storeDP = storeDP + log(M) + lgamma(sum(nodeToComponent[[count, 1]] == i))
        }
        lograt[count] = storesize + storeDP
        print(lograt[count])
        
        if (lograt[count] > 1.2 * min(lograt[1:count])) {
            check = 1
        } else if (count == length(thresh)) {
            check = 1
        }
    }
    lograt = lograt[1:count]
    thresh = thresh[1:count]

    list(nodeToComponent = nodeToComponent, Conf_Set = Conf_Set, prob_set = prob_set, lograt = lograt, thresh = thresh)
}
