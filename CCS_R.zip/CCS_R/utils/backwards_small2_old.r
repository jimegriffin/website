backwards_small2_old = function(nodeToComponent, samples, prob_level) {

    numbofcliques = max(nodeToComponent)
    sizeofcliques = numeric(numbofcliques)

    Conf_Set = matrix(list(), 1, numbofcliques)
    min1 = numeric(numbofcliques)
    min_pos = numeric(numbofcliques)
    prob = matrix(list(), 1, numbofcliques)
    total_prob = rep(1, numbofcliques)
    for (i in 1:numbofcliques) {
        sizeofcliques[i] = sum(nodeToComponent == i)
        Conf_Set[[1, i]] = as.matrix(unique(samples[, nodeToComponent == i]))
        prob[[1, i]] = numeric(dim(Conf_Set[[1, i]])[1])
        for (j in 1:dim(Conf_Set[[1, i]])[1]) {
            v = Conf_Set[[1, i]][j, ]
            M = as.matrix(samples[, nodeToComponent == i])
            prob[[1, i]][j] = sum(rowSums(M == v[col(M)]) == ncol(M))
        }
        prob[[1, i]] = prob[[1, i]] / dim(samples)[1]

        
        x1 = sort(prob[[1, i]], decreasing = TRUE)
        x2 = order(prob[[1, i]], decreasing = TRUE)
        
        prob[[1, i]] = x1
        Conf_Set[[1, i]] = as.matrix(Conf_Set[[1, i]][x2, ])

        min1[i] = min(prob[[1, i]])
        min_pos[i] = which.min(prob[[1, i]])
    }

    
    
    check1 = 0
    while ( check1 == 0 ) {

        oldConf_Set = Conf_Set
        oldprob = prob
        
        score = numeric(dim(Conf_Set)[2])
        for (i in 1:dim(Conf_Set)[2]) {
            if ( length(prob[[1, i]]) > 1 ) {
                score[i] = (min1[i]) / sum(prob[[1, i]]) / (1 / length(prob[[1, i]]))
            } else {
                score[i] = Inf
            }
        }
        
        m2 = which.min(score)
        total_prob[m2] = total_prob[m2] - min1[m2]
        
        if ( min_pos[m2] == 1) {
            indx = (min_pos[m2]+1):dim(Conf_Set[[1, m2]])[1]
        } else if ( min_pos[m2] == dim(Conf_Set[[1, m2]])[1]) {
            indx = 1:(min_pos[m2]-1)
        } else {
            indx = c(1:(min_pos[m2]-1), (min_pos[m2]+1):dim(Conf_Set[[1, m2]])[1])
        }
    
        
        prob[[1, m2]] = prob[[1, m2]][indx]
        if ( sum(nodeToComponent == m2) == 1 )
            Conf_Set[[1, m2]] = Conf_Set[[1, m2]][indx]
        if ( sum(nodeToComponent == m2) > 1 )
            Conf_Set[[1, m2]] = Conf_Set[[1, m2]][indx, ]

        if ( length(prob[[1, m2]]) == 1 ) {
            if ( sum(nodeToComponent == m2) == 1)
                Conf_Set[[1, m2]] = as.matrix(Conf_Set[[1, m2]])
            if ( sum(nodeToComponent == m2) > 1)
                Conf_Set[[1, m2]] = t(Conf_Set[[1, m2]])
        }
        

     
        if ( length(prob[[1, m2]]) > 1) {
            min1[m2] = min(prob[[1, m2]])
            min_pos[m2] = which.min(prob[[1, m2]])
        } else {
            min1[m2] = 1
        }
        
        set_size = prod(total_prob)
        check1 = (set_size < prob_level) + (sum(min1 == 1) == numbofcliques)
    }

    Conf_Set = oldConf_Set
    prob = oldprob


    
#   print("Conf_Set")
#    print(Conf_Set)
#    print("prob_set")
#    print(prob)
    
    
    list(Conf_Set = Conf_Set, prob_set = prob, set_size = set_size)
}
