library(igraph)
library(pracma)
library(Matrix)
library(mgcv)
library(colormap)

setwd("~/Dropbox/Jim share/CurrentPapers/BVS log linear models/code/CCS_R") # Set to the directory containing CCS_R
source("find_CCS.r")
source("plots_CCS.r")
source("screened.r")
source("utils/find_cred_sets_MCMC2.r")
source("utils/find_cred_sets_MCMC3.r")
source("utils/find_uncorrelated2.r")
source("utils/backwards_small2_old.r")
#source("utils/test1.r")



samples = read.csv('samples.txt')


M = 2
prob_level = 0.5
# probability level for Cartesian credible set
threshold = 0.04
# threshold for screening PIPs

names1 = c('S', 'PH', 'NS', 'IFP', 'NLP', 'NGP', 'NGL', 'MHG')

out = find_CCS(samples, names1, prob_level, threshold, M)
thresh = out$thresh
lograt = out$lograt
nodeToComponent = out$nodeToComponent
Conf_Set = out$Conf_Set
prob_set = out$prob_set
names1 = out$VarNames
# thresh = the value of the algorithmic parameter eta
# lograt = the value of the ease-of-understanding penalized criterion
# nodeToComponent = a vector whose i-th entry is the block for the i-th
# variable
# Conf_Set = a cell whose i-th entry is a matrix containing the block
# credible set for the i-th block (each row is a sub-model)
# prob_set = a cell whose i-th entry is a vector giving the marginal PIP
# for each sub-model in the i-th block


totalrows = plots_CCS(nodeToComponent, 1:dim(samples)[2], Conf_Set, prob_set, names1, 15);

