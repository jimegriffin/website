screened = function(samples, threshold) {
    
    numbofits = dim(samples)[1]
    
    PIP = colMeans(samples)
    
    screened_samples = samples[, PIP > threshold]
    
    check1 = sum(samples[, PIP < threshold], 2)
    prob = 1 - sum(check1 > 0) / numbofits

    list(screened_samples = screened_samples, prob = prob)

}
