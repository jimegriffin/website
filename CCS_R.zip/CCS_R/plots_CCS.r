plots_CCS = function(nodeToComponent, variables, Conf_Set, prob_set, VarNames, maxlen2) {

    for (i in 1:length(VarNames)) {
        len1 = nchar(VarNames[i])
        if ( i == 1 ) {
            namelength = len1
        } else if ( len1 > namelength ) {
            namelength = len1
        }
    }
    letterwidth = 1
    bstar = (namelength - namelength * letterwidth) / 2

    bstar = 0.1

    nodeToComponent2 = matrix(list(), 1, max(nodeToComponent))
    for (i in 1:max(nodeToComponent)) {
        nodeToComponent2[[1, i]] = numeric
        nodeToComponent2[[1, i]] = which(nodeToComponent == i)
    }
    check1 = numeric(length(Conf_Set))
    max1 = dim(Conf_Set[[1, 1]])[1]
    sum1 = 0
    for (i in 1:length(Conf_Set)) {
        print(i)
        model_sum = sum(Conf_Set[[1, i]], 2)
        if ( dim(Conf_Set[[1, i]])[2] > 1 ) {
            check1[i] = 1
            sum1 = sum1 + dim(Conf_Set[[1, i]])[2]
        } else if ( sum(model_sum > 0) > 0 ) {
            check1[i] = 1
            sum1 = sum1 + 1
        }
        if ( dim(Conf_Set[[1, i]])[1] > max1 )
            max1 = dim(Conf_Set[[1, i]])[1]
        print(max1)
    }

    


    
    oldConf_Set = Conf_Set
    oldprob_set = prob_set
    oldnodeToComponent2 = nodeToComponent2

    resConf_Set = matrix(list(), 1, sum(check1 == 0))
    resprob_set = matrix(list(), 1, sum(check1 == 0))
    restnodeToComponent2 = matrix(list(), 1, sum(check1 == 0))
    counter = 1
    for (i in 1:dim(Conf_Set)[2]) {
        if ( check1[i] == 0 ) {
            restConf_Set[[1, counter]] = Conf_Set[[1, i]]
            restprob_set[[1, counter]] = prob_set[[1, i]]
            restnodeToComponent2[[1, counter]] = nodeToComponent2[[1, i]]
            counter = counter + 1
        }
    }

    Conf_Set1 = matrix(list(), 1, sum(check1 == 1))
    prob_set1 = matrix(list(), 1, sum(check1 == 1))
    nodeToComponent21 = matrix(list(), 1, sum(check1 == 1))
    for (i in 1:dim(Conf_Set)[2]) {
        if ( check1[1] == 1 ) {
            Conf_Set1[[1, counter]] = Conf_Set[[1, i]]
            prob_set1[[1, counter]] = prob_set[[1, i]]
            nodeToComponent21[[1, counter]] = nodeToComponent2[[1, i]]
            counter = counter + 1
        }
    }

    count = 0
    row = 1
    col = 0
    for (j in 1:length(nodeToComponent21)) {
        if ( col + length(nodeToComponent21[[1, j]]) > maxlen2 ) {
            row = row + 1
            col = 0
        }
        for (i in 1:length(nodeToComponent21[[1, j]])) {
            count = count + 1
            col = col + 1
        }
    }
  
    rowsize = numeric(row)
    sum1 = 0
    max1 = 0
    max2 = 0
    col = 0
    row = 0
    for (i in 1:length(nodeToComponent21)) {
        if ( col + length(nodeToComponent21[[1, i]]) > maxlen2 ) {
            row = row + 1
            if ( row > 0 )
                rowsize[row] = max1 + 2
            col = 0
            max1 = 0
        }
        for (i1 in 1:length(nodeToComponent21[[1, i]])) {
            count = count + 1
            col = col + 1
        }

        model_sum = sum(Conf_Set1[[1, i]], 2)
        if ( dim(Conf_Set1[[1, i]])[2] > 1 ) {
            sum1 = sum1 + dim(Conf_Set1[[1, i]])[2]
        } else if ( sum(model_sum > 0) > 0 ) {
            sum1 = sum1 + 1
        }
        if ( max1 == 0 ) {
            max1 = dim(Conf_Set1[[1, i]])[1]
        } else if ( dim(Conf_Set1[[1, i]])[1] > max1 ) {
            max1 = dim(Conf_Set1[[1, i]])[1]
        }
    }
    rowsize[row + 1] = max1

    rowsize = cumsum(rowsize) / 2

    cmap = colormap('cool')
  
    max1 = rowsize[length(rowsize)]
  
  print("here")
  print(rowsize)
    print(max1)
  
  plot(1, type = "n", xlab = "", ylab = "", xaxt="n", yaxt="n", ann=FALSE, xlim = c(0, sum1+1), ylim = c(-(max1+2), 0))
  
  
  
    count = 0
    row = 1
    col = 0
    for (j in 1:length(nodeToComponent21)) {
        pos1 = sum(Conf_Set1[[1, j]], 2) > 0
        probstar = sum(prob_set1[[1, j]][pos1 == 1])
        if ( col + length(nodeToComponent21[[1, j]]) > maxlen2 ) {
            row = row + 1
            col = 0
        }
        
        for (i in 1:length(nodeToComponent21[[1, j]])) {
            count = count + 1
            col = col + 1

            x1 = (col - 1) * namelength
            x2 = col * namelength
            xax = c(x1, x2, x2, x1)
            if ( row > 1 ) {
                start = rowsize[row - 1]
            } else {
                start = 0
            }

            
            y1 = -start - 0.25
            y2 = -start - 0.75
            yax = c(y1, y1, y2, y2)
            if ( probstar == 0 ) {
                polygon(xax, yax, col = cmap[1])
            } else {
                polygon(xax, yax, col = cmap[ceil(probstar * length(cmap))])
            }

            i1 = nodeToComponent21[[1, j]][i]
            len1 = bstar + letterwidth * (namelength - nchar(VarNames[variables[i1]]))
            
            text((col-0.5)*namelength, -start -0.5, VarNames[variables[i1]], cex = 0.7)
        }
    }
  
  
    count = 0
    row = 1
    col = 0
    for (i in 1:length(nodeToComponent21)) {
        if ( col + length(nodeToComponent21[[1, i]]) > maxlen2 ) {
            row = row + 1
            col = 0
        }

        x1 = col * namelength
        x2 = (col + length(nodeToComponent21[[1, i]])) * namelength

        if ( row > 1 ) {
            start = rowsize[row - 1]
        } else {
            start = 0
        }

        
        lines(c(x1+0.3, x2-0.3),  c(-start-0.15, -start-0.15))

        count = count + length(nodeToComponent21[[1, i]])
        col = col + length(nodeToComponent21[[1, i]])
    }
  
    count = 0
    row = 1
    col = 0
    for (i in 1:length(Conf_Set1)) {
        if ( col + length(nodeToComponent21[[1, i]]) > maxlen2  ) {
            row = row + 1
            col = 0
        }
  
        for (k1 in 1:dim(Conf_Set1[[1, i]])[1]) {
            count1 = count
            col1 = col + 1
            for (k2 in 1:dim(Conf_Set1[[1, i]])[2]) {
                x1 = (col1 - 1) * namelength
                x2 = col1 * namelength
                xax = c(x1, x2, x2, x1)
                if ( row > 1 ) {
                    start = rowsize[row - 1]
                } else {
                    start = 0
                }
                y1 =  -start - (k1 - 0.5) / 2 - 0.5
                y2 =  -start - (k1 + 0.5) / 2 - 0.5
                yax = c(y1, y1, y2, y2)
                polygon(xax, yax, col = cmap[ceil(prob_set1[[1, i]][k1] * length(cmap))])
                text((col1 - 0.5)*namelength, -start  - k1 / 2 - 0.5, Conf_Set1[[1, i]][k1, k2], cex = 0.7)
                count1 = count1 + 1
                col1 = col1 + 1
            }
            if ( row > 1 ) {
                start = rowsize[row - 1]
            } else {
                start = 0
            }
            y1 = -start - (k1 - 0.5) / 2 - 0.5
            y2 = -start - (k1 + 0.5) / 2 - 0.5
            x1 = col * namelength
            x2 = (col+length(nodeToComponent21[[1, i]])) * namelength
        }
        count = count + length(nodeToComponent21[[1, i]])
        col = col + length(nodeToComponent21[[1, i]])


    }
  
  
    lines(c(0, sum1+1, sum1 + 1, 0, 0), c(-max1-1, -max1-1, -max1-1.5, -max1-1.5, -max1-1))
  
    text(0, -max1-1.7, 0)
    for (i in 1:5) {
        pts = (sum1+1) * i / 5
        text(pts, -max1-1.7, i / 5)
    }
    numcols = 100
    for (i in 1:numcols) {
        x1 = ((i - 1) / numcols) * (sum1 + 1)
        x2 = i / numcols * (sum1 + 1)
        xax = c(x1, x2, x2, x1)
        y1 = -max1-1
        y2 = -max1-1.5
        yax = c(y1, y1, y2, y2)
        polygon(xax, yax, col = cmap[ceil((0.5 * x1 + 0.5 * x2) / (sum1 + 1) * length(cmap))], border = NA)
    }
    
    totalrows = 2
    
    totalrows
}
