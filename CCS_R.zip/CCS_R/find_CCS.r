find_CCS = function(samples, VarNames, prob_level, threshold, M) {
    
    type = 2
    
    # type = 1 is thresholded correlation matrix
    # type = 2 is likelihood ratio score
    
    out = screened(samples, threshold)
    samples = out$screened_samples
    prob = out$prob
    
    if ( type == 1 ) {
        thresh = seq(from = 0.95, to = 0.01, length = 199)
    } else {
        thresh = 1:dim(samples)[2]
    }
    storesize = numeric(length(thresh))
    storeDP = numeric(length(thresh))
    lograt = numeric(length(thresh))
    
   
    if ( type == 1 ) {
        check = 0
        count = 0
        while ( check == 0 ) {
            count = count + 1

            out = find_cred_sets_MCMC2(samples, thresh[count], prob_level)
            nodeToComponent = out$nodeToComponent
            Conf_Set = out$Conf_Set
            prob_set = out$prob_set
            set_size = out$set_size
            Corr1 = out$Corr1
            Cov1 = out$Cov1
            

            for (i in 1:length(Conf_Set)) {
                storesize[count] = storesize[count] + log(dim(Conf_Set[[1, i]])[1])
                storeDP[count] = storeDP[count] + log(M) + lgamma(sum(nodeToComponent == i))
            }
            lograt[count] = storesize[count] + storeDP[count]
        
            if (lograt[count] > 1.2 * min(lograt[1:count])) {
                check = 1
            } else if (count == length(thresh)) {
                check = 1
            }
        }
        lograt = lograt[1:count]
        thresh = thresh[1:count]
        
        m1 = min(lograt)
        count = which(lograt == m1)[1]
    
    
        out = find_cred_sets_MCMC2(samples, thresh[count], prob_level)
        nodeToComponent = out$nodeToComponent
        Conf_Set = out$Conf_Set
        prob_set = out$prob_set
        set_size = out$set_size
        Corr1 = out$Corr1
        Cov1 = out$Cov1
    } else {
    
        out = find_cred_sets_MCMC3(samples, count, prob_level)
        nodeToComponent = out$nodeToComponent
        Conf_Set = out$Conf_Set
        prob_set = out$prob_set
        lograt = out$lograt
        thresh = out$thresh
    
        print(lograt)
    
        m1 = min(lograt)
        count = which(lograt == m1)[1]
   
        print(m1)
        print(count)
   
        Conf_Set = Conf_Set[[count, 1]]
        prob_set = prob_set[[count, 1]]
        nodeToComponent = nodeToComponent[[count, 1]]
    }
    
    print(nodeToComponent)
    print(Conf_Set)
    print(Conf_Set[[1, 1]])
    print(dim(Conf_Set))
    print(dim(prob_set))
    print(VarNames)

    check = rep(0, length(Conf_Set))
    for (i in 1:length(Conf_Set)) {
        check2 = rep(0, dim(Conf_Set[[1, i]])[2])
        for (j in 1:dim(Conf_Set[[1, i]])[2]) {
            if ( sum(Conf_Set[[1, i]][, j]) == 0 ) {
                check2[j] = 1
            }
        }
        Conf_Set[[1, i]] = Conf_Set[[1, i]][, check2 == 0]
        if ( i == 1 ) {
            print("here1")
            print(Conf_Set[[1, i]])
        }
        if ( sum(check2 == 0) == 1 )
            Conf_Set[[1, i]] = as.matrix(Conf_Set[[1, i]])
        if ( i == 1 ) {
            print("here2")
            print(Conf_Set[[1, i]])
        }
        
        if ( sum(check2) > 0 ) {
            pos = which(nodeToComponent == i)
            nodeToComponent = nodeToComponent[- pos[check2 == 1]]
            VarNames = VarNames[- pos[check2 == 1]]
        }
        if ( isempty(Conf_Set[[1, i]]) == 1 )
            check[i] = 1
    }

    print(Conf_Set[[1, 1]])

    
    checkstar = which(check == 0)
    Conf_Set = t(as.matrix(Conf_Set[1, checkstar]))
    prob_set = t(as.matrix(prob_set[1, checkstar]))

    for (j in 1:max(nodeToComponent))
        nodeToComponent[nodeToComponent == j] = sum(1 - check[1:j])


    
    list(thresh = thresh, lograt = lograt, nodeToComponent = nodeToComponent, Conf_Set = Conf_Set, prob_set = prob_set, VarNames = VarNames)
}
