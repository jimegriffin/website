library(igraph)
library(pracma)
library(Matrix)
library(mgcv)
library(colormap)

setwd("~/Dropbox/Jim share/CurrentPapers/BVS log linear models/code/CCS_R")
source("find_CCS.r")
source("plots_CCS.r")
source("screened.r")
source("utils/find_cred_sets_MCMC2.r")
source("utils/find_cred_sets_MCMC3.r")
source("utils/find_uncorrelated2.r")
source("utils/backwards_small2_old.r")
#source("utils/test1.r")



samples = read.table('results_concrete.txt')


prob_level = 0.5

type = 2
# type = 1 is thresholded correlation matrix
# type = 2 is likelihood ratio score
M = 2
prob_level = 0.5
# probability level for Cartesian credible set
threshold = 0.04
# threshold for screening PIPs

out = find_CCS(samples, prob_level, threshold, type, M)
thresh = out$thresh
lograt = out$lograt
nodeToComponent = out$nodeToComponent
Conf_Set = out$Conf_Set
prob_set = out$prob_set
# thresh = the value of the algorithmic parameter eta
# lograt = the value of the ease-of-understanding penalized criterion
# nodeToComponent = a vector whose i-th entry is the block for the i-th
# variable
# Conf_Set = a cell whose i-th entry is a matrix containing the block
# credible set for the i-th block (each row is a sub-model)
# prob_set = a cell whose i-th entry is a vector giving the marginal PIP
# for each sub-model in the i-th block

plot(thresh, lograt)

names1 = c('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13')

allnames = vector(length = 91)
allnames[1:13] = names1

counter = 13
for (i in 2:13)
    for (j in 1:(i-1)) {
        counter = counter + 1
        allnames[counter] = paste(names1[i], "x", names1[j])
    }

totalrows = plots_CCS(nodeToComponent, 1:dim(samples)[2], Conf_Set, prob_set, allnames, 13)



