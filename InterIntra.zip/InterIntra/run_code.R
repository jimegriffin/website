library(readxl)
library(lubridate)
#library(Matrix)
#library(logOfGamma)
#library(ggplot2)
library(dplyr)
#library(matrixcalc)
#library(EnvStats)
#library(MASS)
#library(mnormt)
#library(pracma)
#library(tmvtnorm)
#library(tmvmixnorm)


setwd("~/Dropbox/Jim share/Performance modelling - local/Shrunk intra-inter/release version")


source("fit_model.R")
data = read.csv("Swimming_Dist_100m_Female_Freestyle.csv")
dim(data)


ID = data$ID
unique_ID = unique(ID)
n = rep(0, length(unique_ID))
for (i in 1:length(unique_ID))
    n[i] = sum(ID == unique_ID[i])

ord = order(n, decreasing = TRUE)
unique_ID = unique_ID[ord]

data=data  %>% filter(ID %in% unique_ID[1:500])
ID = data$ID

age1 = data$AgeNum
ResultDate = data$ResultDate
dat1 = paste(year(ResultDate), '0101', sep = "")
year1 = year(ResultDate)
within1 = (interval(ymd(dat1), ResultDate) %/% days(1)) / 365
target1 = data$TimeSeconds
pool1 = data$PoolConfiguration == "25m"

unique_ID = unique_ID[1:500]

age_all = rep(list(), length(unique_ID))
season_all = rep(list(), length(unique_ID))
within_all = rep(list(), length(unique_ID))
target_all = rep(list(), length(unique_ID))
pool_all = rep(list(), length(unique_ID))
for (i in 1:length(unique_ID)) {
    ind = ID == unique_ID[i]
    season = year1[ind == 1]
    season_all[[i]] = season - min(season) + 1
    age_all[[i]] = age1[ind == 1]
    within_all[[i]] = within1[ind == 1]
    target_all[[i]] = target1[ind == 1]
    pool_all[[i]] = pool1[ind == 1]
}

n_all = rep(0, length(unique_ID))
for (i in 1:length(unique_ID))
    n_all[i] = sum(ID == unique_ID[i])

n_athlete = length(unique_ID)

degree = 4
regressors_a = rep(list(), n_athlete)
for (i in 1:n_athlete) {
    regressors_a[[i]] = matrix(1, nrow = n_all[i], degree + 2)
    for (j in 1:degree)
        regressors_a[[i]][, j + 1] = (age_all[[i]] - mean(age1))^j
    regressors_a[[i]][, degree + 2] = pool_all[[i]]
}

min1 = min(age1)
max1 = max(age1)

knots_age = seq(from = min1, to = max1, length = 31)

out = fit_model(age_all, within_all, regressors_a, NULL, NULL, knots_age, target_all, season_all, "negative", 5000, 1000, 5)

