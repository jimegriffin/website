library(MASS)
library(EnvStats)
library(tmvtnorm)
library(GIGrvg)
library(pracma)


fit_model <- function(ages, times, regressors_a, target, season, direction, burnin, numbofits, every){
    
    # The inputs are
    # ages = Ages of all athletes
    # times = The date of the performances within each season scaled to be between 0 and 1
    # regressors_a = covariates for each performance
    # target = Performances of all athletes
    # season = Season of each performance
    # direction = direction of improvement
    # burnin = number of burn-in iterations
    # numbofits = number of collected samples
    # every = thinning and so the sampler is run for burnin + numbofits * every iterations in total
    
    # The outputs are samples of parameters. Using notation in the paper,
    # a_sigmasqbeta_ind = \tau_0
    # a_sigmasqbeta_t_ind = \lambda_0
    # b_sigmasqbeta_ind = \tau_1
    # b_sigmasqbeta_t_ind = \lambda_1
    # beta_a = \zeta
    # beta_b = \beta
    # beta_bi = \beta^{(i)}
    # beta_bit = \beta^{(i, s)}
    # F = F
    # nu_inc = \nu^{\eta}
    # nu_start = \nu^{\mu}
    # nu1 = \nu_1
    # nu2 = \nu_1
    # sigmasq = \sigma^2_i
    # sigmasq_inc = \sigma^2_{\eta}
    # sigmasq_rw_3 = \sigma^2_{\eta, 2}
    # sigmasq_start = \sigma^2_{\mu}
    # sigmasqalpha = \sigma^2_{\alpha}
    # sigmasqbeta = d
    # sigmasqbeta_ind = \tau
    # sigmasqbeta_t = c
    # sigmasqbeta_t_ind = \lambda
    # sigmasqbeta0 = \sigma^2_{\beta, 0}
    # sigmasqmu = \sigma^2_{m}
    # skew_alpha = \alpha
    
    numb_seasons = rep(0, n_athlete)
    sumy = 0
    sumx = 0
    sumysq = 0
    count = 0
    for (i in 1:n_athlete) {
        sumy = sumy + sum(target[[i]])
        sumx = sumx + sum(ages[[i]])
        sumysq = sumysq + sum(target[[i]]^2)
        count = count + length(target[[i]])
        numb_seasons[i] = max(season[[i]])
    }
    meanx = sumx / count
    meany = sumy / count
    var_initial = (sumysq - sumy^2 / count) / (count - 1)
        
    n_athlete = length(times)
    spline_age_width = 9
    regressors_b = rep(list(), n_athlete)
    p_a = ncol(regressors_a[[1]])
    if (is.null(p_a))
        p_a = 1
 
    for (i in 1:n_athlete)
        regressors_b[[i]] = TruncBernstein(times[[i]], 4)
    p_b = dim(regressors_b[[1]])[2]
 
 
 
    Amat = rep(list(), 4)
    Amat[[2]] = 1
    Amat[[3]] = matrix(c(2, -1, -1, 2), 2, 2)
    Amat[[4]] = matrix(c(6, -4, 0, -3, 8, 3, 0, -4, 6), nrow = 3, ncol = 3)
    Amat_all = matrix(0, nrow = p_b, ncol = p_b)
    Amat_all[1:1] = Amat[[2]]
    Amat_all[2:3, 2:3] = Amat[[3]]
    Amat_all[4:6, 4:6] = Amat[[4]]
    
    invAmat = rep(list(), 4);
    invAmat[[2]] = 1
    invAmat[[3]] = solve(Amat[[3]])
    invAmat[[4]] = solve(Amat[[4]])
    invAmat_all = matrix(0, nrow = p_b, ncol = p_b)
    invAmat_all[1:1] = invAmat[[2]]
    invAmat_all[2:3, 2:3] = invAmat[[3]]
    invAmat_all[4:6, 4:6] = invAmat[[4]]

    
    
    col_bern = rep(list(), 4)
    col_bern[[2]] = 1
    col_bern[[3]] = c(2, 3)
    col_bern[[4]] = c(4, 5, 6)
    
    
    
    print(paste('n_athlete =',n_athlete))# num2str()
    print(paste('p_a =', p_a))
    print(paste('p_b =', p_b))

    ##################
  
    beta_a = rep(0, p_a)
    beta_b = rep(0, p_b)
    beta_bi = newbeta_bi = matrix(0, p_b, n_athlete)
    beta_bit = newbeta_bit = lapply(1:n_athlete, function(i) {matrix(0, numb_seasons[i], p_b) })
  
    sigmasqbeta = rep(0.01 * var_initial, p_b)
    sigmasqbeta_t = rep(0.01 * var_initial, p_b)
    sigmasqbeta_ind = rep(0.01 * var_initial, n_athlete)
    sigmasqbeta_t_ind = rep(0.01 * var_initial, n_athlete)
    sigmasqbeta0 = rep(0.01 * var_initial, p_b)
    skew_alpha = 2
    nu1 = 20
    nu2 = 5
    nu_start = 20
    nu_inc = 20
    omega_inc = rep(list(), n_athlete)
    zskew = rep(list(), n_athlete)
    omega = rep(list(), n_athlete)
    omega2 = rep(list(), n_athlete)
    resid2 = rep(list(), n_athlete)
    omega_start = 1 / rgamma(n_athlete, shape = 0.5 * nu_start, rate = 0.5 * nu_start)
  
    a_sigmasqbeta = 5
    b_sigmasqbeta = 5
    a_sigmasqbeta_ind = 5
    b_sigmasqbeta_ind = 1
    mu_sigmasqbeta_ind = a_sigmasqbeta_ind / b_sigmasqbeta_ind
    a_sigmasqbeta_t = 5
    b_sigmasqbeta_t = 5
    a_sigmasqbeta_t_ind = 5
    b_sigmasqbeta_t_ind = 1
    mu_sigmasqbeta_t_ind = a_sigmasqbeta_t_ind / b_sigmasqbeta_t_ind

    m_sigmasqbeta = 1
    m_sigmasqbeta_t = 1

    #### initialize variables ####
    hyper5 = 0.001
    sigmasq = rep(var_initial, n_athlete)
    sigmasq_inc = 1
    sigmasq_start = var_initial
    sigmasq_rw_3 = 1
    pred_times = seq(0, 1, length.out = 21)
    sigmasqalpha = 5
    sigmasqmu = 0.1
    storeF = lapply(1:n_athlete, function(i){matrix(0, numb_seasons[i] + 1, numbofits) })
  
    storesigmasq = matrix(0, n_athlete, numbofits)
    storenu1 = storenu2 = storenu_start = storenu_inc = rep(0, numbofits)
    storesigmasq_start = storesigmasq_inc = storesigmasq_rw_3 = rep(0, numbofits)
    storebeta_a = matrix(0, p_a, numbofits)
    storebeta_b = matrix(0, p_b, numbofits)
    storebeta_bi = rep(list(matrix(0, n_athlete, p_b)), numbofits)
    storebeta_bit = rep(list(list()), n_athlete)
    storebeta_bit = lapply(1:n_athlete, function(i){ rep(list(matrix(0, numb_seasons[i], p_b)), numbofits)})
 
    storesigmasqbeta0 = matrix(0, p_b, numbofits)
    storesigmasqalpha = rep(0, numbofits)
    storesigmasqbeta = matrix(0, p_b, numbofits)
    storesigmasqbeta_t = matrix(0, p_b, numbofits)
    storesigmasqbeta_ind = matrix(0, n_athlete, numbofits)
    storesigmasqbeta_t_ind = matrix(0, n_athlete, numbofits)

    storea_sigmasqbeta_ind = rep(0, numbofits)
    storeb_sigmasqbeta_ind = rep(0, numbofits)
    storea_sigmasqbeta_t_ind = rep(0, numbofits)
    storeb_sigmasqbeta_t_ind = rep(0, numbofits)

    storesigmasqmu = storeskew_alpha = rep(0, numbofits)
    storespline_age_width = rep(0, numbofits)
    diststar = diststarpred = rep(list(list()), n_athlete)
    diststar = diststarpred = lapply(1:n_athlete, function(i){ rep(list(list()), numb_seasons[i]) })
    A = XTX = rep(list(list()), n_athlete)
    Fsub = rep(list(), n_athlete)
    Fsub = lapply(1:n_athlete, function(i){rep(list(list()), numb_seasons[i]) })
    F = lapply(1:n_athlete, function(i){rep(0, numb_seasons[i] + 1) })
  
    lognu1sd = lognu2sd = lognu_startsd = lognu_incsd = logsigmasqalphasd = log(0.01)
    logskew_alphasd = logspline_age_widthsd = log(0.01)
    logsigmasqbetasd = log(0.01)
    loga_sigmasqbeta_indsd = log(0.01)
    loga_sigmasqbeta_t_indsd = log(0.01)

    sum1_spline_width = rep(list(matrix(0, 2, 1)), n_athlete + 1)
    sum2_spline_width = rep(list(matrix(0, 2, 2)), n_athlete + 1)
    count_spline_width = rep(0, n_athlete + 1)

    Tstar = 0:1
    for (i in 1:n_athlete) {
        for (j in 1:numb_seasons[i]) {
            if ( sum(season[[i]] == j) > 0 ) {
                diststar[[i]][[j]] = matrix(0, 2, sum(season[[i]] == j))
            
                sub1 = times[[i]][season[[i]] == j]
                for (k1 in 1:length(Tstar))
                    for (k2 in 1:sum(season[[i]] == j))
                        diststar[[i]][[j]][k1, k2] = abs(Tstar[k1] - sub1[k2])
            }
            
            diststarpred[[i]][[j]] = matrix(0, 2, length(pred_times))
            for (k1 in 1:length(Tstar))
                for (k2 in 1:length(pred_times))
                    diststarpred[[i]][[j]][k1, k2] = abs(Tstar[k1] - pred_times[k2])
            
        }
    }
    B = matrix(0, p_b + 2, p_b + 2)
    B[1, 2] = B[2, 2] = 1
    B[3:dim(B)[1],3:dim(B)[2]] = diag(p_b)
    B2 = matrix(0, 2, 2)
    B2[1, 2] = B2[2, 2] = 1
    D = matrix(0, p_b + 2, p_b + 2)
    D2 = rep(0, 4)
  

  
    for (i in 1:n_athlete) {
        A[[i]] = rep(list(), numb_seasons[i])
        XTX[[i]] = rep(list(), numb_seasons[i])
        for (j in 1:numb_seasons[i]) {
            if (sum(season[[i]] == j) > 0) {
                A[[i]][[j]] = 1 - t(diststar[[i]][[j]])
                if ( sum(season[[i]] == j) > 1 ) {
                    XTX[[i]][[j]] = regressors_b[[i]][season[[i]] == j, ] %*% t(regressors_b[[i]][season[[i]] == j, ])
                } else {
                    XTX[[i]][[j]] = sum(regressors_b[[i]][season[[i]] == j, ]^2)
                }
            }
        }
    }
  
  
    nu1accept = nu2accept = nu_startaccept = nu_incaccept = sigmasqalphaaccept = skew_alphaaccept = 0
    spline_age_widthaccept = 0
    sigmasqbetaaccept  = rep(0, n_athlete + 1)
    nu1count  =  nu2count  = nu_startcount  =  nu_inccount = sigmasqalphacount = skew_alphacount = 0
    spline_age_widthcount  = 0
    sigmasqbetacount = rep(0, n_athlete + 1)
    
    a_sigmasqbeta_indaccept = 0
    a_sigmasqbeta_indcount = 0
    a_sigmasqbeta_t_indaccept = 0
    a_sigmasqbeta_t_indcount = 0
    

  
    sumx = 0
    sumxsq = 0
    n_total = 0
    for (i in 1:n_athlete) {
        sumx = sumx + sum(target[[i]])
        sumxsq = sumxsq + sum(target[[i]]^2)
        n_total = n_total + length(target[[i]])
    }
  
    regressors_F = rep(list(), n_athlete)

    for (i in 1:n_athlete) {
        regressors_F[[i]] = matrix(0, dim(regressors_a[[i]])[1], numb_seasons[i] + 1)
        for (j in 1:numb_seasons[i])
            regressors_F[[i]][season[[i]] == j, j:(j+1)] = A[[i]][[j]]
    }


  
    sum1 = matrix(0, p_a, p_a)
    sum1[2:p_a, 2:p_a] = n_total / 100 * diag(p_a - 1)
    sum2 = rep(0, p_a)
    sum3 = 0
    for (i in 1:n_athlete) {
        reg1 = regressors_a[[i]]
        sum1 = sum1 + t(reg1) %*% reg1
        sum2 = sum2 + t(reg1) %*% target[[i]]
        sum3 = sum3 + sum(target[[i]]^2)
    }
  
    beta_a = solve(sum1) %*% sum2

    
   
    for (i in 1:n_athlete)
        resid2[[i]] = target[[i]] - regressors_a[[i]] %*% beta_a


        
    sum1 = 100 * diag(p_b)
    sum2 = rep(0, p_b)
    sum3 = 0
    for (i in 1:n_athlete) {
        for (j in 1:numb_seasons[i]) {
            if ( sum(season[[i]] == j) > 0 ) {
                ord = which.min(times[[i]][season[[i]]] == j)
                if ( times[[i]][ord] < 0.25 ) {
                    inc = season[[i]] == j
                    if (sum(inc) > 1) {
                        reg_sub = regressors_b[[i]][inc == 1, ]
                    } else {
                        reg_sub = t(as.matrix(regressors_b[[i]][inc == 1, ]))
                    }
                    resid1 = resid2[[i]][inc == 1] - resid2[[i]][ord]
               
                    sum1 = sum1 + t(reg_sub) %*% reg_sub
                    sum2 = sum2 + t(reg_sub) %*% resid1
                    sum3 = sum3 + sum(resid1^2)
                }
            }
        }
    }
    beta_b = solve(sum1) %*% sum2
    for (i in 2:length(col_bern)) {
        err = Amat[[i]] %*% beta_b[col_bern[[i]]]
        err[err > 0] = -0.01
        beta_b[col_bern[[i]]] = invAmat[[i]] %*% err
    }


    

    
    
    for (i in 1:n_athlete)
        resid2[[i]] = resid2[[i]] - regressors_b[[i]] %*% beta_b

  
    RSS = 0
    dof = 0
    for (i in 1:n_athlete) {
        sum1star = matrix(0, length(F[[i]]), 1)
        sum2star = diag(rep(0.01, length(F[[i]])))
        sum3star = 0
        dof_local = 0

        regressorsstar = regressors_F[[i]]
                          
        sum1star = sum1star + t(regressors_F[[i]]) %*% resid2[[i]]
        sum2star = sum2star + t(regressors_F[[i]]) %*% regressors_F[[i]]
        sum3star = sum3star + sum(resid2[[i]]^2)
        dof_local = dof_local + length(resid2[[i]])
        
        F[[i]] = solve(sum2star) %*% sum1star
    }
    
    
    for (i in 1:n_athlete)
        resid2[[i]] = resid2[[i]] - regressors_F[[i]] %*% F[[i]] + regressors_b[[i]] %*% beta_b

                    
    for (i in 1:n_athlete) {
        sum1 = 100 * diag(p_b) + t(regressors_b[[i]]) %*% regressors_b[[i]]
        sum2 = 100 * beta_b + t(regressors_b[[i]]) %*% resid2[[i]]
        sum3 = sum(resid2[[i]]^2)

        beta_bi[, i] = solve(sum1) %*% sum2
    }
    

                
    for (i in 1:n_athlete)
        resid2[[i]] = resid2[[i]] - regressors_b[[i]] %*% beta_bi[, i]


    sum1 = 0
    sum2 = 0
    for (i in 1:n_athlete) {
        sum1 = sum1 + length(target[[i]])
        sum2 = sum2 + sum(resid2[[i]]^2)
    }
        
    var_initial = sum2 / sum1

    sigmasq_alpha = rep(10, n_athlete)
    sigmasq_beta = rep(var_initial*10, n_athlete)

  
    for (i in 1:n_athlete) {
        for (k in 1:numb_seasons[i])
            beta_bit[[i]][k, ] = beta_bi[, i]
        zskew[[i]] = rep(0, length(target[[i]]))
        resid2[[i]] = target[[i]] - zskew[[i]]
        resid2[[i]] = resid2[[i]] - regressors_a[[i]] %*% beta_a
        resid2[[i]] = resid2[[i]] - rowSums(regressors_b[[i]] * beta_bit[[i]][season[[i]], ])
            
        omega[[i]] = 1 / rgamma(length(target[[i]]), shape = 0.5 * nu1, rate= 0.5 * nu1)
        omega2[[i]] = 1 / rgamma(length(target[[i]]), shape = 0.5 * nu2, rate= 0.5 * nu2)
    }
    omega_inc = lapply(1:n_athlete, function(i){1 / rgamma(numb_seasons[i], shape = .5 * nu_inc, rate= .5 * nu_inc)})
  
  

  
    print(paste("total iterations =", burnin + numbofits*every))
  
    ########## MCMC loop ##########################
    #Rprof("file.out")
    start2 = Sys.time()
    for ( it in 1:(burnin + numbofits*every) ) {
         
        if ( it%%20 == 0) { 
            
            print(paste('it =', it))
            ######
            print(paste('beta_a = ', t(beta_a)))
            print(paste('a_sigmasqbeta_ind =', a_sigmasqbeta_ind))
            print(paste('mu_sigmasqbeta_ind =', 1 / mu_sigmasqbeta_ind))
            print(paste('a_sigmasqbeta_t_ind =', a_sigmasqbeta_t_ind))
            print(paste('mu_sigmasqbeta_t_ind =', 1 / mu_sigmasqbeta_t_ind))
            print(paste('sigmasq_start =', sigmasq_start))
            print(paste('sigmasq_inc =', sigmasq_inc))
            print(paste('sigmasq_rw_3 =', sigmasq_rw_3))
            print(paste('nu1 accept =', nu1accept/nu1count))
            print(paste('nu2 accept =', nu2accept/nu2count))
            print(paste('nu_start accept =', nu_startaccept/nu_startcount))
            print(paste('nu_inc accept =', nu_incaccept/nu_inccount))
            print(c(min(sigmasqbetaaccept[1:n_athlete] / sigmasqbetacount[1:n_athlete]), max(sigmasqbetaaccept[1:n_athlete] / sigmasqbetacount[1:n_athlete])))
            print(sigmasqbetaaccept[1+n_athlete] / sigmasqbetacount[1+n_athlete])
            print(sigmasqbeta_t)
            print(sigmasqbeta)
            print(a_sigmasqbeta_indaccept / a_sigmasqbeta_indcount)
            print(a_sigmasqbeta_t_indaccept / a_sigmasqbeta_t_indcount)
        }
        
        ###### Residuals update ###
        for (i in 1:n_athlete) {
            resid2[[i]] = (target[[i]] - skew_alpha / sqrt(1 + skew_alpha^2) * zskew[[i]])
            resid2[[i]] = resid2[[i]] - regressors_a[[i]] %*% beta_a
        }
  

        ### 1. Jointly update F and beta_i ###
        for (i in 1:n_athlete) {
            sum1star = matrix(0, p_b + length(F[[i]]), 1)
            sum1star[1:p_b, 1] = beta_b / (sigmasqbeta * sigmasqbeta_ind[i])
            sum2star = matrix(0, p_b + length(F[[i]]), p_b + length(F[[i]]))
            sum2star[1:p_b, 1:p_b] = diag(1 / (sigmasqbeta * sigmasqbeta_ind[i]))
            if ( length(F[[i]]) == 1) {
                sum2star[(p_b + 1):(p_b + length(F[[i]])), (p_b + 1):(p_b + length(F[[i]]))] = diag(1 / sigmasq_start)
            } else if (length(F[[i]]) == 2 ) {
                Astar = matrix(c(1, -1, 0, 1), 2, 2)
                sum2star[(p_b + 1):(p_b + length(F[[i]])), (p_b + 1):(p_b + length(F[[i]]))] = t(Astar) %*% diag(c(1 / sigmasq_start, 1 / sigmasq_inc)) %*% Astar
            } else if (length(F[[i]]) == 3 ) {
              Astar = Toeplitz(c(1,-1,1, rep(0, length(F[[i]]) - 3)), c(1, rep(0, length(F[[i]]) - 1)))
              Astar[3:length(F[[i]]) ,2:(length(F[[i]]) - 1)] = diag(-2, length(F[[i]]) - 2)
              sum2star[(p_b + 1):(p_b + length(F[[i]])), (p_b + 1):(p_b + length(F[[i]]))] = t(Astar) %*% diag(c(1 / sigmasq_start, 1 / sigmasq_inc, 1 / sigmasq_rw_3)) %*% Astar
            } else {
              Astar = Toeplitz(c(1,-1,1, rep(0, length(F[[i]]) - 3)), c(1, rep(0, length(F[[i]]) - 1)))
              Astar[3:length(F[[i]]) ,2:(length(F[[i]]) - 1)] =  diag(-2, length(F[[i]]) - 2) + Toeplitz(c(0, 1, rep(0, (length(F[[i]]) - 4))))
              sum2star[(p_b + 1):(p_b + length(F[[i]])), (p_b + 1):(p_b + length(F[[i]])) ] = t(Astar) %*% diag(c(1 / sigmasq_start, 1 / sigmasq_inc, 1 / rep(sigmasq_rw_3, length(F[[i]]) - 2))) %*% Astar
            }

            for (j in 1:numb_seasons[i]) {
                if (sum(season[[i]] == j) > 0) {
                    inc = season[[i]] == j
                    if ( sum(inc) > 1) {
                        reg2 = regressors_b[[i]][inc == 1, ]
			 var1 = diag(sigmasq[i] * omega[[i]][inc == 1]) + sigmasqbeta_t_ind[i] * reg2 %*% diag(sigmasqbeta_t) %*% t(reg2)
                    } else {
                        reg2 = t(as.matrix(regressors_b[[i]][inc == 1, ]))
			 var1 = sigmasq[i] * omega[[i]][inc == 1] + sigmasqbeta_t_ind[i] * reg2 %*% diag(sigmasqbeta_t) %*% t(reg2)
                    }

                   
                    Z1 = matrix(0, sum(season[[i]] == j), length(F[[i]]) )
                    Z1[,j:(j+1)] = A[[i]][[j]]
                    if (sum(season[[i]] == j) > 1) {
                        reg_sub = regressors_b[[i]][season[[i]] == j, ]
                    } else {
                        reg_sub = t(as.matrix(regressors_b[[i]][season[[i]] == j, ]))
                    }
                    regress_star = cbind(reg_sub, Z1)
                    invvar1 = solve(var1)
                    sum1star = sum1star + t(regress_star) %*% invvar1 %*% resid2[[i]][season[[i]] == j]
                    sum2star = sum2star + t(regress_star) %*% invvar1 %*% regress_star
                }
            }
          
          
            indx1 = 1:p_b
            indx2 = (p_b+1):(p_b+length(F[[i]]))
            x = block_mvn(sum1star, sum2star, indx1, indx2)
          
            F[[i]] = x[indx2]
            beta_bi[, i] = x[indx1]
          
            Fsub[[i]] = regressors_F[[i]] %*% F[[i]]
            resid2[[i]] = resid2[[i]] - Fsub[[i]]
        }

        ### 2. Update beta_{i, s} ####
        for (i in 1:n_athlete) {
            for (j in 1:numb_seasons[i]) {
                inc = season[[i]] == j
                if ( sum(inc) > 0 ) {
                    if (sum(inc) > 1) {
                        reg_sub = regressors_b[[i]][inc == 1, ]
                    } else {
                        reg_sub = t(as.matrix(regressors_b[[i]][inc == 1, ]))
                    }
                    regress_star = reg_sub / (sqrt(sigmasq[i] * omega[[i]][inc == 1]))
                    resid_star = resid2[[i]][inc == 1] / sqrt(sigmasq[i] * omega[[i]][inc == 1])
                    sum1b2 = beta_bi[, i] / (sigmasqbeta_t * sigmasqbeta_t_ind[i]) + t(regress_star) %*% resid_star
                    sum2b2 = diag(1 / (sigmasqbeta_t * sigmasqbeta_t_ind[i])) + t(regress_star) %*% regress_star
                    varstar = solve(sum2b2)
                    varstar = 0.5 * varstar + 0.5 * t(varstar)
                    mustar = varstar %*% sum1b2
                } else {
                    mustar = beta_bi[, i]
                    varstar = diag(sigmasqbeta_t * sigmasqbeta_t_ind[i])
                }
                beta_bit[[i]][j, ] = mvrnorm(1, mustar, varstar)
                if ( sum(inc) > 0 )
                    resid2[[i]][inc == 1] = resid2[[i]][inc == 1] - reg_sub %*% beta_bit[[i]][j, ]
            }
        }



        
        
        ### 3. Update zskew ###
        for (i in 1:n_athlete) {
            var1 = sigmasq[i] / (1 / omega2[[i]] + (skew_alpha^2 / (1 + skew_alpha^2)) / omega[[i]])
            resid2[[i]] = resid2[[i]] + skew_alpha / sqrt(1 + skew_alpha^2) * zskew[[i]]
            mu1 = (skew_alpha / sqrt(1 + skew_alpha^2) * resid2[[i]] / omega[[i]]) / (1 / omega2[[i]] + (skew_alpha^2 / (1 + skew_alpha^2)) / omega[[i]])
            zskew[[i]] = rnormTrunc(length(zskew[[i]]), mean = mu1, sd = sqrt(var1), min = 0, max = Inf)
            resid2[[i]] = resid2[[i]] - skew_alpha / sqrt(1 + skew_alpha^2) * zskew[[i]]
        }
        
      
        
        

        
        ### 4. Jointly update beta_a and beta_b ####
        sum1 = matrix(0, p_a + p_b, 1)
        sum1[(p_a + 1):(p_a + p_b)] = 0
        sum2 = matrix(0, p_b + p_a, p_b + p_a)
        sum2[(p_a + 1):dim(sum2)[1],(p_a + 1):dim(sum2)[2]] = diag(1 / sigmasqbeta0)
        for (i in 1:n_athlete) {
            sum1star = matrix(0, length(F[[i]]), p_a + p_b)
            sum2star = matrix(0, length(F[[i]]), length(F[[i]]))
            sum3star = matrix(0, length(F[[i]]), 1)
            if ( length(F[[i]]) == 1) {
                Astar = as.matrix(1)
                sum2star[1:length(F[[i]]), 1:length(F[[i]])] = t(Astar) %*% diag(1 / sigmasq_start) %*% Astar
            } else if (length(F[[i]]) == 2 ) {
                Astar = matrix(c(1, -1, 0, 1), 2, 2)
                sum2star[1:length(F[[i]]), 1:length(F[[i]])] = t(Astar) %*% diag(c(1 / sigmasq_start, 1 / sigmasq_inc)) %*% Astar
            } else if (length(F[[i]]) == 3 ) {
              Astar = Toeplitz(c(1,-1,1, rep(0, length(F[[i]]) - 3)), c(1, rep(0, length(F[[i]]) - 1)))
              Astar[3:length(F[[i]]) ,2:(length(F[[i]]) - 1)] =  diag(- 2, length(F[[i]]) - 2)
              sum2star[1:length(F[[i]]), 1:length(F[[i]])] = t(Astar) %*% diag(c(1 / sigmasq_start, 1 / sigmasq_inc, 1 / sigmasq_rw_3)) %*% Astar
            } else {
              Astar = Toeplitz(c(1, -1, 1, rep(0, length(F[[i]]) - 3)), c(1, rep(0, length(F[[i]]) - 1)))
              Astar[3:length(F[[i]]), 2:(length(F[[i]]) - 1)] =  diag(-2, length(F[[i]]) - 2) + Toeplitz(c(0, 1, rep(0, (length(F[[i]]) - 4))))
              sum2star[1:length(F[[i]]), 1:length(F[[i]])] = t(Astar) %*% diag(c( 1 / sigmasq_start, 1 / sigmasq_inc, 1 / rep(sigmasq_rw_3, length(F[[i]]) - 2))) %*% Astar
            }
            
            regress_star = cbind(regressors_a[[i]], regressors_b[[i]]) / sqrt(sigmasq[i] * omega[[i]])
            resid_star = (target[[i]] - skew_alpha / sqrt(1 + skew_alpha^2) * zskew[[i]]) / sqrt(sigmasq[i] * omega[[i]])
            for (k in 1:length(resid_star))
                resid_star[k] = resid_star[k] - sum(regressors_b[[i]][k, ] * (beta_bit[[i]][season[[i]][k], ] - beta_b)) / sqrt(sigmasq[i] * omega[[i]][k])
 
            regress_star2 = regressors_F[[i]] / sqrt(sigmasq[i] * omega[[i]])

            sum1 = sum1 + t(regress_star) %*% resid_star
            sum2 = sum2 + t(regress_star) %*% regress_star
            sum1star = sum1star + t(regress_star2) %*% regress_star
            sum2star = sum2star + t(regress_star2) %*% regress_star2
            sum3star = sum3star + t(regress_star2) %*% resid_star

            invsum2star = solve(sum2star)
            sum2 = sum2 - t(sum1star) %*% invsum2star %*% sum1star
            sum1 = sum1 - t(sum1star) %*% invsum2star %*% sum3star
        }
        
        out1 = solve_safe(sum2)
        if (out1$check == 1) {
            varstar3 = out1$invmat
            mustar3 = varstar3 %*% sum1
    
            oldbeta_a = beta_a
            oldbeta_bit = beta_bit
            oldbeta_b = beta_b
        
            varstar3_sub = varstar3[(p_a + 1):(p_a + p_b), (p_a + 1):(p_a + p_b)]
            mustar3_sub = mustar3[(p_a + 1):(p_a + p_b)]
    
            out1 = solve_safe(varstar3_sub)
    
            if ( out1$check == 1 ) {
                invvarstar3_sub = out1$invmat
            
                trans_var = Amat_all %*% varstar3_sub %*% t(Amat_all)
                trans_mu = Amat_all %*% mustar3_sub
    
                err_old = Amat_all %*% beta_b
    
                if ( direction == "negative" ) {
                    err = rtmvnorm(1, mean = as.vector(trans_mu), sigma = trans_var, upper = rep(0, p_b), algorithm = "gibbs", start.value = err_old)
                } else {
                    err = rtmvnorm(1, mean = as.vector(trans_mu), sigma = trans_var, lower = rep(0, p_b), algorithm = "gibbs", start.value = err_old)
                }
                beta_b = invAmat_all %*% t(err)
      
                mustar_cond = mustar3[1:p_a] + varstar3[1:p_a, (p_a + 1):(p_a + p_b)] %*% invvarstar3_sub %*% (beta_b - mustar3_sub)
                varstar_cond = varstar3[1:p_a, 1:p_a] - varstar3[1:p_a, (p_a + 1):(p_a + p_b)] %*% invvarstar3_sub %*% varstar3[(p_a + 1):(p_a + p_b), 1:p_a]
   
                zstar = mvrnorm(1, mustar_cond, varstar_cond)
                beta_a = zstar[1:p_a]
        
                for (i in 1:n_athlete) {
                    for (j in 1:numb_seasons[i])
                        beta_bit[[i]][j, ] = beta_b + beta_bit[[i]][j, ]  - as.numeric(oldbeta_b)
                    beta_bi[, i] = beta_b + beta_bi[, i] - as.numeric(oldbeta_b)
                }
    
                for (i in 1:n_athlete) {
                    resid2[[i]] = resid2[[i]] - regressors_a[[i]] %*% (beta_a - oldbeta_a)
                    resid2[[i]] = resid2[[i]] - rowSums(regressors_b[[i]] * (beta_bit[[i]][season[[i]], ] - oldbeta_bit[[i]][season[[i]], ]))
                }
            }
        }
    
        ### 5. Update F_i ###
        for (i in 1:n_athlete) {
            resid2[[i]] = resid2[[i]] + Fsub[[i]]
            
            start2 = Sys.time()
            sum1star = matrix(0, length(F[[i]]), 1)
            sum2star = matrix(0, length(F[[i]]), length(F[[i]]))
            if ( length(F[[i]]) == 1) {
                Astar = as.matrix(1)
                sum2star[1:length(F[[i]]), 1:length(F[[i]]) ] = t(Astar) %*% diag(1 / sigmasq_start) %*% Astar
            } else if (length(F[[i]]) == 2 ) {
                Astar = matrix(c(1, -1, 0, 1), 2, 2)
                sum2star[1:length(F[[i]]), 1:length(F[[i]]) ] = t(Astar) %*% diag(c(1 / sigmasq_start, 1 / sigmasq_inc)) %*% Astar
            } else if (length(F[[i]]) == 3 ) {
                Astar = Toeplitz(c(1, -1, 1, rep(0, length(F[[i]]) - 3)), c(1, rep(0, length(F[[i]]) - 1)))
                Astar[3:length(F[[i]]) ,2:(length(F[[i]]) - 1)] =  diag(-2, length(F[[i]]) - 2)
                sum2star[1:length(F[[i]]), 1:length(F[[i]])] = t(Astar) %*% diag(c(1 / sigmasq_start, 1 / sigmasq_inc, 1 / sigmasq_rw_3)) %*% Astar
            } else {
                Astar = Toeplitz(c(1, -1, 1, rep(0, length(F[[i]]) - 3)), c(1, rep(0, length(F[[i]]) - 1)))
                Astar[3:length(F[[i]]), 2:(length(F[[i]]) - 1)] =  diag(- 2, length(F[[i]]) - 2) + Toeplitz(c(0, 1, rep(0, length(F[[i]]) - 4)))
                sum2star[1:length(F[[i]]), 1:length(F[[i]])] = t(Astar) %*% diag(c(1 / sigmasq_start, 1 / sigmasq_inc, 1 / rep(sigmasq_rw_3, length(F[[i]]) - 2))) %*% Astar
            }

            regress_star = regressors_F[[i]] / sqrt(sigmasq[i] * omega[[i]])
            resid_star = resid2[[i]] / sqrt(sigmasq[i] * omega[[i]])
            sum1star = sum1star + t(regress_star) %*% resid_star
            sum2star = sum2star + t(regress_star) %*% regress_star
            
            invsum2star = solve(sum2star)
            F[[i]] = mvrnorm(1, invsum2star %*% sum1star, invsum2star)
      
            Fsub[[i]] = regressors_F[[i]] %*% F[[i]]
            resid2[[i]] = resid2[[i]] - Fsub[[i]]
        }
        
     
    
    
      
        
        ### 6. Update sigmasqalpha ###
        newsigmasqalpha = sigmasqalpha * exp(exp(logsigmasqalphasd) * rnorm(1))
        loglike = n_athlete * (sigmasqalpha * log(sigmasqalpha / sigmasqmu) - lgamma(sigmasqalpha)) - (sigmasqalpha + 1) * sum(log(sigmasq)) - (sigmasqalpha / sigmasqmu) * sum(1 / sigmasq)
        newloglike = n_athlete * (newsigmasqalpha * log(newsigmasqalpha / sigmasqmu) - lgamma(newsigmasqalpha)) - (newsigmasqalpha + 1) * sum(log(sigmasq)) - (newsigmasqalpha / sigmasqmu) * sum(1 / sigmasq)
        logaccept3 = newloglike - loglike
        
        accept = 1
        if ( is.na(logaccept3)|is.infinite(logaccept3) ) {
            accept = 0
        } else if ( logaccept3 < 0 ) {
            accept = exp(logaccept3)
        }
        
        if ( runif(1) < accept )
            sigmasqalpha = newsigmasqalpha                            # using the new sigmasqalpha
    
        sigmasqalphaaccept = sigmasqalphaaccept + accept
        sigmasqalphacount = sigmasqalphacount + 1
        logsigmasqalphasd = logsigmasqalphasd + it^(-0.7) * (accept - 0.3)
 
 
        ### 7. Update sigmasqmu ###
        sigmasqmu = 1 / rgamma(1, n_athlete * sigmasqalpha, sum(sigmasqalpha / sigmasq))

        
        
        
        ### 8. Update skew_alpha ####
        newskew_alpha = skew_alpha + exp(logskew_alphasd) * rnorm(1)
        
        loglike = newloglike = 0
        for (i in 1:n_athlete) {
            resid2[[i]] = resid2[[i]] + skew_alpha / sqrt(1 + skew_alpha^2) * zskew[[i]]
            
            loglike = loglike - 0.5 * sum((resid2[[i]] - skew_alpha / sqrt(1 + skew_alpha^2) * zskew[[i]])^2 / (sigmasq[i] * omega[[i]]))
            newloglike = newloglike - 0.5 * sum((resid2[[i]] - newskew_alpha / sqrt(1 + newskew_alpha^2) * zskew[[i]])^2 / (sigmasq[i] * omega[[i]]))
        }
        logaccept4 = newloglike - loglike - 0.5 * newskew_alpha^2 / 3^2 + 0.5 * skew_alpha^2 / 3^2
        
        accept = 1
        if ( is.na(logaccept4) | is.infinite(logaccept4) ) {
            accept = 0
        } else if (logaccept4 < 0) {
            accept = exp(logaccept4)
        }

        if ( runif(1) < accept)
            skew_alpha = newskew_alpha
    
        skew_alphaaccept = skew_alphaaccept + accept
        skew_alphacount = skew_alphacount + 1
        logskew_alphasd = logskew_alphasd + it^(-.7) * (accept - .3)
    
        for (i in 1:n_athlete)
            resid2[[i]] =  resid2[[i]] - skew_alpha / sqrt(1 + skew_alpha^2) * zskew[[i]]


    
        ### 9. Update of sigmasqbeta ###
        sum2 = rep(0, p_b)
        for (i in 1:p_b)
            sum2[i] = sum2[i] + sum((beta_bi[i, ] - beta_b[i])^2 / sigmasqbeta_ind)
                
        sigmasqbeta = 1 / rgamma(p_b, shape = 0.5 * n_athlete + a_sigmasqbeta, rate = 0.5 * sum2 + b_sigmasqbeta)

        
        
        ### 10. Update of sigmasqbeta_ind ###
        sum2 = rep(0, n_athlete)
        for (i in 1:p_b)
            sum2 = sum2 + (beta_bi[i, ] - beta_b[i])^2 / sigmasqbeta[i]
        
        lambda_GIG = a_sigmasqbeta_ind - 0.5 * p_b
        chi_GIG = 0.5 * sum2
        psi_GIG = b_sigmasqbeta_ind

        for (i in 1:n_athlete)
            sigmasqbeta_ind[i] = rgig(1, lambda_GIG, 2 * chi_GIG[i], 2 * psi_GIG)
                 
                 
        ### 11. Interweaving of sigmasqbeta_ind and sigmasqbeta ###
        psi_beta = sigmasqbeta_ind * m_sigmasqbeta
        eta_beta = sigmasqbeta / m_sigmasqbeta

        alpha_IG = 0.001 + n_athlete * a_sigmasqbeta_ind + p_b * a_sigmasqbeta
        beta_IG = 0.001 + b_sigmasqbeta_ind * sum(psi_beta) + b_sigmasqbeta * sum(1 / eta_beta)
 
        oldm_sigmasqbeta = m_sigmasqbeta
        m_sigmasqbeta = 1 / rgamma(1, shape = alpha_IG, rate = beta_IG)
        
        sigmasqbeta_ind = psi_beta / m_sigmasqbeta
        sigmasqbeta = eta_beta * m_sigmasqbeta

        
        
        ### 12. Update of a_sigmasqbeta_ind ###
        newa_sigmasqbeta_ind = a_sigmasqbeta_ind * exp(exp(loga_sigmasqbeta_indsd) * rnorm(1))
        loglike = n_athlete * (a_sigmasqbeta_ind * log(a_sigmasqbeta_ind / mu_sigmasqbeta_ind) - lgamma(a_sigmasqbeta_ind)) + (a_sigmasqbeta_ind - 1) * sum(log(sigmasqbeta_ind)) - (a_sigmasqbeta_ind / mu_sigmasqbeta_ind) * sum(sigmasqbeta_ind)
        newloglike = n_athlete * (newa_sigmasqbeta_ind * log(newa_sigmasqbeta_ind / mu_sigmasqbeta_ind) - lgamma(newa_sigmasqbeta_ind)) + (newa_sigmasqbeta_ind - 1) * sum(log(sigmasqbeta_ind)) - (newa_sigmasqbeta_ind / mu_sigmasqbeta_ind) * sum(sigmasqbeta_ind)
        logaccept = newloglike - loglike
        logaccept = logaccept + log(newa_sigmasqbeta_ind) - log(a_sigmasqbeta_ind)
        logaccept = logaccept - newa_sigmasqbeta_ind + a_sigmasqbeta_ind

        accept = 1
        if ( is.na(logaccept) | is.infinite(logaccept) ) {
            accept = 0
        } else if ( logaccept < 0 ) {
            accept = exp(logaccept)
        }
        
        if ( runif(1) < accept )
            a_sigmasqbeta_ind = newa_sigmasqbeta_ind
    
        a_sigmasqbeta_indaccept = a_sigmasqbeta_indaccept + accept
        a_sigmasqbeta_indcount = a_sigmasqbeta_indcount + 1
        loga_sigmasqbeta_indsd = loga_sigmasqbeta_indsd + it^(-0.7) * (accept - 0.3)
        
        
        ### 13. Update of mu_sigmasqbeta_ind ###
        mu_sigmasqbeta_ind = 1 / rgamma(1, shape = n_athlete * a_sigmasqbeta_ind + 0.001, rate = 0.001 + sum(a_sigmasqbeta_ind * sigmasqbeta_ind))
    
        b_sigmasqbeta_ind = a_sigmasqbeta_ind / mu_sigmasqbeta_ind
        
        
        
        
        ### 13. Update sigmasqbeta_t ###
        sum1 = rep(0, p_b)
        sum2 = rep(0, p_b)
        for (i in 1:n_athlete) {
            sum1 = sum1 + dim(beta_bit[[i]])[1]
            for (j in 1:p_b)
                sum2[j] = sum2[j] + sum((beta_bit[[i]][, j] - beta_bi[j, i])^2 / sigmasqbeta_t_ind[i])
        }
        sigmasqbeta_t = 1 / rgamma(p_b, shape = 0.5 * sum1 + a_sigmasqbeta_t, rate = 0.5 * sum2 + b_sigmasqbeta_t)
        
        
        ### 14. Update sigmasqbeta_t_ind ###
        for (i in 1:n_athlete) {
            sum1 = dim(beta_bit[[i]])[1] * p_b
            sum2 = 0
            for (j in 1:p_b)
                sum2 = sum2 + sum((beta_bit[[i]][, j] - beta_bi[j, i])^2 / sigmasqbeta_t[j])
                
            lambda_GIG = a_sigmasqbeta_t_ind - 0.5 * sum1
            chi_GIG = 0.5 * sum2
            psi_GIG = b_sigmasqbeta_t_ind

            sigmasqbeta_t_ind[i] = rgig(1, lambda_GIG, 2 * chi_GIG, 2 * psi_GIG)
        }
        
        
        ### 15. Interweaving of sigmasqbeta_t and sigmasqbeta_t_ind ###
        eta_beta_t = sigmasqbeta_t / m_sigmasqbeta_t
        psi_beta_t = sigmasqbeta_t_ind * m_sigmasqbeta_t
        
        alpha_IG = 0.001 + n_athlete * a_sigmasqbeta_t_ind + p_b * a_sigmasqbeta_t
        beta_IG = 0.001 + b_sigmasqbeta_t_ind * sum(psi_beta_t) + b_sigmasqbeta_t * sum(1 / eta_beta_t)
 
        oldm_sigmasqbeta = m_sigmasqbeta
        m_sigmasqbeta = 1 / rgamma(1, shape = alpha_IG, rate = beta_IG)
        
        sigmasqbeta_t_ind = psi_beta_t / m_sigmasqbeta_t
        sigmasqbeta_t = eta_beta_t * m_sigmasqbeta_t

        
        ### 16. Update of a_sigmasqbeta_t_ind ###
        newa_sigmasqbeta_t_ind = a_sigmasqbeta_t_ind * exp(exp(loga_sigmasqbeta_t_indsd) * rnorm(1))
        loglike = n_athlete * (a_sigmasqbeta_t_ind * log(a_sigmasqbeta_t_ind / mu_sigmasqbeta_t_ind) - lgamma(a_sigmasqbeta_t_ind)) + (a_sigmasqbeta_t_ind - 1) * sum(log(sigmasqbeta_t_ind)) - (a_sigmasqbeta_t_ind / mu_sigmasqbeta_t_ind) * sum(sigmasqbeta_t_ind)
        newloglike = n_athlete * (newa_sigmasqbeta_t_ind * log(newa_sigmasqbeta_t_ind / mu_sigmasqbeta_t_ind) - lgamma(newa_sigmasqbeta_t_ind)) + (newa_sigmasqbeta_t_ind - 1) * sum(log(sigmasqbeta_t_ind)) - (newa_sigmasqbeta_t_ind / mu_sigmasqbeta_t_ind) * sum(sigmasqbeta_t_ind)
        logaccept = newloglike - loglike
        logaccept = logaccept + log(newa_sigmasqbeta_t_ind) - log(a_sigmasqbeta_t_ind)
        logaccept = logaccept - newa_sigmasqbeta_t_ind + a_sigmasqbeta_t_ind

        accept = 1
        if ( is.na(logaccept) | is.infinite(logaccept) ) {
            accept = 0
        } else if ( logaccept < 0 ) {
            accept = exp(logaccept)
        }
        
        if ( runif(1) < accept )
            a_sigmasqbeta_t_ind = newa_sigmasqbeta_t_ind
    
        a_sigmasqbeta_t_indaccept = a_sigmasqbeta_t_indaccept + accept
        a_sigmasqbeta_t_indcount = a_sigmasqbeta_t_indcount + 1
        loga_sigmasqbeta_t_indsd = loga_sigmasqbeta_t_indsd + it^(-0.7) * (accept - 0.3)
        
        
        
        ### 17. Update mu_sigmasqbeta_t_ind ###
        mu_sigmasqbeta_t_ind = 1 / rgamma(1, shape = n_athlete * a_sigmasqbeta_t_ind + 0.001, rate = 0.001 + sum(a_sigmasqbeta_t_ind * sigmasqbeta_t_ind))
    
        b_sigmasqbeta_t_ind = a_sigmasqbeta_t_ind / mu_sigmasqbeta_t_ind
        
        
        
        ### 18. Update sigmasqbeta0 ###
        sigmasqbeta0 = 1 / rgamma(p_b, shape = 5 + 0.5, rate = 1 + 0.5 * beta_b^2)

    
        ### 19. Update sigmasq_start ###
        alphastar = 0.001 + n_athlete/2
        betastar = 0.001
        for (i in 1:n_athlete)
            betastar = betastar + 0.5 * F[[i]][1]^2
        sigmasq_start = 1 / rgamma(1, alphastar, rate = betastar)

    
    
    
        ### 20. Update nu1 ###
        newnu1 = nu1 * exp(exp(lognu1sd) * rnorm(1))
        loglike = newloglike = 0
        for (i in 1:n_athlete) {
            loglike = loglike + length(target[[i]]) * (nu1 / 2 * log(nu1 / 2) - lgamma(nu1 / 2) + lgamma((nu1 + 1) / 2))
            loglike  = loglike - ((nu1 + 1) / 2) * sum(log(0.5 * nu1 + 0.5 * resid2[[i]]^2 / sigmasq[i]))
            newloglike = newloglike + length(target[[i]]) * (newnu1 / 2 * log(newnu1 / 2) - lgamma(newnu1 / 2) + lgamma((newnu1 + 1) / 2))
            newloglike = newloglike - ((newnu1 + 1) / 2) * sum(log(0.5 * newnu1 + 0.5 * resid2[[i]]^2 / sigmasq[i]))
        }
        logaccept5 = newloglike - loglike + (log(newnu1)-log(nu1)) -.1*(newnu1 - nu1)
        
        accept = 1
        if ( is.na(logaccept5)|is.infinite(logaccept5) ) {
            accept = 0
        } else if ( logaccept5 < 0 ) {
            accept = exp(logaccept5)
        }
        
        if ( runif(1) < accept )
            nu1 = newnu1
    
        nu1accept = nu1accept + accept
        nu1count = nu1count + 1
        lognu1sd = lognu1sd + it^(-0.7) * (accept - 0.3)
    

    
    
        ### 21. Update nu2 ###
        newnu2 = nu2 * exp(exp(lognu2sd) * rnorm(1))
        loglike = newloglike = 0
    
        for (i in 1:n_athlete) {
            loglike = loglike + length(target[[i]]) * (nu2 / 2 * log(nu2 / 2) - lgamma(nu2 / 2) + lgamma((nu2 + 1) / 2) )
            loglike = loglike - 0.5 * (nu2 + 1) * sum(log(0.5 * (nu2 + zskew[[i]]^2 / sigmasq[i])))
            newloglike = newloglike + length(target[[i]]) * (newnu2 / 2 * log(newnu2 / 2) - lgamma(newnu2 / 2) + lgamma((newnu2 + 1) / 2) ) #
            newloglike  = newloglike - 0.5 * (newnu2 + 1) * sum(log(0.5 * (newnu2 + zskew[[i]]^2 / sigmasq[i])))
        }
        logaccept6 = newloglike - loglike + (log(newnu2)-log(nu2)) - 0.1 * (newnu2 - nu2)
        
        accept = 1
        if ( is.na(logaccept6)|is.infinite(logaccept6) ) {
            accept = 0
        } else if ( logaccept6 < 0 ) {
            accept = exp(logaccept6)
        }
        
        if ( runif(1) < accept )
            nu2 = newnu2
    
        nu2accept = nu2accept + accept
        nu2count = nu2count + 1
        lognu2sd = lognu2sd + it^(-0.7) * (accept - 0.3)
    
    

        ### 22. Update omega, omega2 and sigmasq ###
        for (i in 1:n_athlete) {
            betastar = 0.5 * nu1 + 0.5 * resid2[[i]]^2 / sigmasq[i]
            omega[[i]] = 1 / rgamma(length(target[[i]]), shape = 0.5 * nu1 + 0.5, rate = betastar)
                    
            betastar = 0.5 * nu2 + 0.5 * zskew[[i]]^2 / sigmasq[i]
            omega2[[i]] = 1 / rgamma(length(target[[i]]), shape = 0.5 * nu2 + 0.5 ,rate = betastar)
                    
            sum1 = sum(resid2[[i]]^2 / omega[[i]]) + sum(zskew[[i]]^2 / omega2[[i]])
            sum3 = length(resid2[[i]])
            sigmasq[i] = 1 / rgamma(1, shape = sigmasqalpha + sum3, rate = sigmasqalpha / sigmasqmu + sum1 / 2)
        }
    


    
        ### 23. Update nu_start ###
        newnu_start = nu_start * exp(exp(lognu_startsd) * rnorm(1))
         
        loglike = n_athlete * (nu_start / 2 * log(nu_start / 2) - lgamma(nu_start / 2) + lgamma(0.5 * nu_start + 0.5))
        newloglike = n_athlete * (newnu_start / 2 * log(newnu_start / 2) - lgamma(newnu_start / 2) + lgamma(0.5 * newnu_start + 0.5) )

        for (i in 1:n_athlete) {
            loglike = loglike - (0.5 * nu_start + 0.5) * log(0.5 * (nu_start + F[[i]][1]^2 / sigmasq_start))
            newloglike = newloglike - (0.5 * newnu_start + 0.5) * log(0.5 * (newnu_start + F[[i]][1]^2 / sigmasq_start))
        }
        logaccept = newloglike - loglike + log(newnu_start) - log(nu_start) - 0.1 * (newnu_start - nu_start)
        
        accept = 1
        if ( is.na(logaccept) | is.infinite(logaccept) ) {
            accept = 0
        } else if ( logaccept < 0 ) {
            accept = exp(logaccept)
        }
        
        if ( runif(1) < accept )
            nu_start = newnu_start
            
        nu_startaccept = nu_startaccept + accept
        nu_startcount = nu_startcount + 1
        lognu_startsd = lognu_startsd + it^(-0.7) * (accept - 0.3)
    

    
        ### 24. Update sigmasq_inc  ###
        alphastar = 0.001 + 0.5 * n_athlete
        betastar = 0.001
        for (i in 1:n_athlete)
            betastar = betastar + 0.5 * (diff(as.numeric(F[[i]]))[1])^2
        sigmasq_inc = 1 / rgamma(1, alphastar, rate = betastar)
    
        
        ### 25. Update sigmasq_rw_3 ###
        alphastar = 0.001
        betastar = 0.001
        for (i in 1:n_athlete) {
          alphastar = alphastar + 0.5 * (length(F[[i]]) - 2)
          Second_diff = diff(as.numeric(F[[i]]), differences = 2)^2
          betastar = betastar + 0.5 * ifelse(identical(Second_diff, numeric(0)), 0, sum(Second_diff))
        }
        sigmasq_rw_3 = 1/rgamma(1, alphastar, rate = betastar)
        
            
            
        ### 26. Update nu_inc ###
        newnu_inc = nu_inc * exp(exp(lognu_incsd) * rnorm(1))
        loglike = newloglike = 0
        for (i in 1:n_athlete) {
            loglike = loglike + (length(F[[i]]) - 1) * (nu_inc / 2 * log(nu_inc / 2) - lgamma(nu_inc / 2) + lgamma(0.5 * nu_inc + 0.5))
            loglike = loglike - (0.5 * nu_inc + 0.5) * sum(log(0.5 * nu_inc + 0.5 * (diff(as.numeric(F[[i]]))^2) / sigmasq_inc))
         
            newloglike = newloglike + (length(F[[i]]) - 1) * (newnu_inc / 2 * log(newnu_inc / 2) - lgamma(newnu_inc / 2) + lgamma(0.5 * newnu_inc + 0.5))
            newloglike = newloglike - (0.5 * newnu_inc + 0.5) * sum(log(0.5 * newnu_inc + 0.5 * (diff(as.numeric(F[[i]]))^2) / sigmasq_inc))
        }
        logaccept = newloglike - loglike + log(newnu_inc) - log(nu_inc) - 0.1 * (newnu_inc - nu_inc)
        
        accept = 1
        if ( is.na(logaccept) | is.infinite(logaccept) ) {
            accept = 0
        } else if ( logaccept < 0 ) {
            accept = exp(logaccept)
        }
         
        if ( runif(1) < accept )
            nu_inc  = newnu_inc
         
         nu_incaccept = nu_incaccept + accept
         nu_inccount = nu_inccount + 1
         lognu_incsd = lognu_incsd + it^(- 0.7) * (accept - 0.3)
    
      
    
    
        ### store parameters ###
        if ( (it > burnin) && ( (it - burnin)%%every == 0) ) {
            it2  = (it - burnin) / every
            for (i in 1:n_athlete) {
                storeF[[i]][, it2] = F[[i]]
            }
            storesigmasq[, it2] = sigmasq
            storesigmasq_start[it2] = sigmasq_start
            storesigmasq_inc[it2] = sigmasq_inc
            storesigmasq_rw_3[it2] = sigmasq_rw_3
            
            storesigmasqalpha[it2] = sigmasqalpha
            storesigmasqmu[it2]  = sigmasqmu
            storesigmasqbeta0[, it2] = sigmasqbeta0
            storesigmasqbeta[, it2] = sigmasqbeta
            storesigmasqbeta_t[, it2] = sigmasqbeta_t
            storesigmasqbeta_ind[, it2] = sigmasqbeta_ind
            storesigmasqbeta_t_ind[, it2] = sigmasqbeta_t_ind

            storea_sigmasqbeta_ind[it2] = a_sigmasqbeta_ind
            storeb_sigmasqbeta_ind[it2] = b_sigmasqbeta_ind
            storea_sigmasqbeta_t_ind[it2] = a_sigmasqbeta_t_ind
            storeb_sigmasqbeta_t_ind[it2] = b_sigmasqbeta_t_ind

            
            storenu1[it2] = nu1
            storenu2[it2] = nu2
            storenu_start[it2] = nu_start
            storenu_inc[it2] = nu_inc
      
 
            storebeta_a[, it2] = beta_a
            storebeta_b[, it2] = beta_b
            storebeta_bi[[it2]] = t(beta_bi)
            for (i in 1:n_athlete)
                storebeta_bit[[i]][[it2]] = beta_bit[[i]]
 
            storeskew_alpha[it2] = skew_alpha
        }
    }

    
    
    
    return(list('a_sigmasqbeta_ind' = storea_sigmasqbeta_ind, 'a_sigmasqbeta_t_ind' = storea_sigmasqbeta_t_ind, 'b_sigmasqbeta_ind' = storeb_sigmasqbeta_ind,  'b_sigmasqbeta_t_ind' = storeb_sigmasqbeta_t_ind, 'beta_a' = storebeta_a, 'beta_b' = storebeta_b, 'beta_bi' = storebeta_bi, 'beta_bit' = storebeta_bit, 'F' = storeF, 'nu_inc' = storenu_inc, 'nu_start' = storenu_start, 'nu1' = storenu1, 'nu2' = storenu2, 'sigmasq' = storesigmasq, 'sigmasq_inc' = storesigmasq_inc, 'sigmasq_rw_3' = storesigmasq_rw_3, 'sigmasq_start' = storesigmasq_start, 'sigmasqalpha' = storesigmasqalpha, 'sigmasqbeta' = storesigmasqbeta, 'sigmasqbeta_ind' = storesigmasqbeta_ind, 'sigmasqbeta_t' = storesigmasqbeta_t, 'sigmasqbeta_t_ind' = storesigmasqbeta_t_ind, 'sigmasqbeta0' = storesigmasqbeta0, 'sigmasqmu' = storesigmasqmu, 'skew_alpha' = storeskew_alpha))
}



solve_safe <- function(mat) {

    try_inverse = try(solve(mat), silent = TRUE)
    if ( inherits(try_inverse, "try-error") == FALSE ) {
        invmat = try_inverse
        check = 1
    } else {
        invmat = 0
        check = 0
    }
    
    return(list(invmat = invmat, check = check))
}


block_mvn <- function(sum1star, sum2star, indx1, indx2) {
    
     x = numeric(length(indx1) + length(indx2))
    
    Astar = sum2star[indx2, indx2]
    Bstar = sum2star[indx2, indx1]
    Dstar = sum2star[indx1, indx1]
    invAstar = solve(Astar)

    S = Dstar - t(Bstar) %*% invAstar %*% Bstar
    invS = solve(S);
    part1 = solve(invAstar + invAstar %*% Bstar %*% invS %*% t(Bstar) %*% invAstar)
    part2 = - invS %*% t(Bstar) %*% invAstar
    P = sum1star[indx2, 1]
    Q = sum1star[indx1, 1]

    varstar1 = invAstar - invAstar %*% Bstar %*% part2
    mustar1 = invAstar %*% P + invAstar %*% Bstar %*% invS %*% t(Bstar) %*% invAstar %*% P - invAstar %*% Bstar %*% invS %*% Q
        
        
    x[indx2] = mvrnorm(1, mustar1, varstar1)

    mustar3 = part2 %*% P + invS %*% Q + part2 %*% part1 %*% (x[indx2] - mustar1)
    varstar3 = invS - part2 %*% part1 %*% t(part2)
    
    x[indx1] = mvrnorm(1, mustar3, varstar3)

    return(x)
}



TruncBernstein = function(x, degree) {
    F1 = matrix(0,length(x), degree * (degree - 1) / 2)
    
    count = 0
    for (i in 2:degree) {
        for (j in 2:i) {
            j1 = j - 1
            count = count + 1
            F1[, count] = exp(lgamma(i + 1) - lgamma(j1 + 1) - lgamma(i - j1 + 1)) * (x^j1) * ((1 - x)^(i - j1))
        }
    }
    return(F1)
}
