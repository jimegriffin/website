cd ..
load 'Concrete_Data trim.txt'

Concrete = Concrete_Data_trim;

target = Concrete(:, 9);
data = Concrete(:, 1:8);
data = [data log(data(:, [1 4 6 7 8]))];
datastar = zeros(size(data, 1), 20);
datastar(:, 1:13) = data;
count = 14;
for i = 2:size(data, 2)
    for j = 1:(i-1)        
        datastar(:, count) = data(:, i) .* data(:, j);
        count = count + 1;
    end
end
    
meandata = mean(datastar);
for i = 1:size(datastar, 2)
    datastar(:, i) = (datastar(:, i) - meandata(i));
end
target = target - mean(target);



g = 100;
gprior = 0;
mode = 1;
hparam = 5 / 100;
tau = 0.25;
nu = 1;
RB = 1;
adap_type = 1;
num_burn= 100;
num_its = 200;
num_thin = 1;
num_reps = 25;

% [output_IA] = EIA_sampler(data, target, g, gprior, mode, RB, hparam, nu, num_burn, num_its, num_thin, num_reps, 1, adap_type);
% figure(1)
% subplot(2,2,1)
% plot(output_IA.prob_inclusion)
% subplot(2,2,2)
% plot(output_IA.modelsize)
% subplot(2,2,3)
% plot(output_IA.zetaAS)
% subplot(2,2,4)
% plot(output_IA.zetaDS)

RB_adap = 1;

[output_ASI] = ASI_sampler(datastar, target, g, gprior, mode, RB_adap, RB, hparam, tau, nu, num_burn, num_its, num_thin, num_reps, 1, adap_type);

figure(2)
subplot(2,2,1)
plot(output_ASI.prob_inclusion)
subplot(2,2,2)
plot(output_ASI.modelsize)
subplot(2,2,3)
plot(output_ASI.zetaAS)
subplot(2,2,4)
plot(output_ASI.zetaDS)
