function [output] = EIA_sampler(data_fixed, data, target, g, gprior, mode, RB, hparam, nu, burnin, numbofits, thin, numbofreps, heat, adap_type, updateg)

rhostar = zeros(1, length(heat) - 1);
for i = 1:(length(heat)-1)
    rhostar(i) = log(log(heat(i)/heat(i+1)));
end
order = zeros(numbofreps, length(heat));
for rep = 1:numbofreps
    order(rep, :) = 1:length(heat);
end

[n p] = size(data);
pfixed = size(data_fixed, 2);

tauL = 0.05;
tauU = 0.23;

sigmasqalpha = 0;
sigmasqbeta = 0;

numbofchains = length(heat);

g = g * ones(numbofreps, numbofchains);

if ( length(hparam) == 1 )
    fixed = 1;
    w = hparam * ones(numbofreps, numbofchains);
    wstar = hparam;
else
    fixed = 0;
    wa = hparam(1);
    wb = hparam(2);
    wstar = wa / (wa + wb);
end

logita = 1 / p;
logitb = 1 - 1 / p;

XTy_all = data' * target;
XTy_fixed = data_fixed' * target;

loglike = zeros(numbofreps, numbofchains);

C = cell(numbofreps, numbofchains);
gamma = zeros(numbofreps, p, numbofchains);
for chain = 1:numbofchains
    for rep = 1:numbofreps
        gamma(rep, :, chain) = rand(1, p) < wstar;
        
        datastar = [ones(n, 1) data_fixed data(:, gamma(rep, :, chain)==1)];
        if ( gprior == 1 )
            n0star = zeros(1 + pfixed + sum(gamma(rep, :, chain)));
            n0star((2 + pfixed):(1+pfixed+sum(gamma(rep, :, chain))), (2 + pfixed):(1+pfixed+sum(gamma(rep, :, chain)))) = 1 / g(rep, chain)  * datastar(:, (2 + pfixed):end)' * datastar(:, (2 + pfixed):end);
        else
            n0star = 1 / g(rep, chain) * eye(sum(gamma(rep, :, chain)) + pfixed + 1);
            n0star(1:(pfixed+1), 1:(pfixed+1)) = 0;
        end
        C{rep, chain} = inv(datastar' * datastar + n0star);
        XTy = [sum(target); XTy_fixed; XTy_all(gamma(rep, :, chain)==1)];
        
        loglike(rep, chain) = - 0.5 * sum(gamma(rep, :, chain)) * log(g(rep, chain)) - 0.5 * log(det(datastar' * datastar + n0star));
        loglike(rep, chain) = loglike(rep, chain) - 0.5 * n * log(target' * target - XTy' * C{rep, chain} * XTy);
    end
end

zetaAS = nu / ((1 - wstar) * p) * ones(numbofchains, p);
if ( zetaAS(1, 1) > 1 )
    zetaAS = 0.1 * ones(numbofchains, p);
end
zetaDS = nu / (wstar * p) * ones(numbofchains, p);
if ( zetaDS(1, 1) > 1 )
    zetaDS = 0.1 * ones(numbofchains, p);
end
logitzetaAS = log(zetaAS - logita) - log(logitb - zetaAS);
logitzetaDS = log(zetaDS - logita) - log(logitb - zetaDS);

totalaccept = zeros(1, numbofchains);
totalcount = zeros(1, numbofchains);
totalchange = zeros(1, numbofchains);

totalaccept2 = zeros(1, numbofchains - 1);
totalcount2 = zeros(1, numbofchains - 1);
gaccept = zeros(1, numbofchains);
gcount = zeros(1, numbofchains);
                
loggsd = zeros(1, numbofchains);

sumgamma = zeros(1, p);
sumgamma2 = zeros(1, p);
holdmodelsize = zeros(numbofits, numbofreps);
holdloglike = zeros(numbofits, numbofreps);
holdaccept = zeros(numbofits, 1);
if ( mode == 2 )
    holdgamma = zeros(numbofreps, numbofits, p);
else
    holdgamma = [];
end
for it = 1:(burnin+numbofits*thin)
    
     if ( mod(it, 100) == 0 )
        disp(['it = ' num2str(it)]);
        disp(['numbofreps = ' num2str(numbofreps)]);
        disp(['accept = ' num2str(totalaccept./totalcount)]);
        disp(['change = ' num2str(totalchange./totalcount)]);
        disp(num2str(heat));
        disp(num2str(totalaccept2./totalcount2));
        disp(' ');
    end
    
    
    for chain = 1:numbofchains
        for rep = 1:numbofreps
            chain1 = order(rep, chain);
            
            check1 = logitzetaAS(chain1, :)<0;
            check2 = logitzetaDS(chain1, :)<0;
            zetaAS(check1==1) = (logita + logitb * exp(logitzetaAS(chain1, check1==1))) ./ (1 + exp(logitzetaAS(chain1, check1==1)));
            zetaDS(check2==1) = (logita + logitb * exp(logitzetaDS(chain1, check2==1))) ./ (1 + exp(logitzetaDS(chain1, check2==1)));
            zetaAS(check1==0) = (logita * exp(- logitzetaAS(chain1, check1==0)) + logitb) ./ (exp(- logitzetaAS(chain1, check1==0)) + 1);
            zetaDS(check2==0) = (logita * exp(- logitzetaDS(chain1, check2==0)) + logitb) ./ (exp(- logitzetaDS(chain1, check2==0)) + 1);
            
            gammaA = zeros(1, p);
            gammaD = zeros(1, p);
            newgamma = gamma(rep, :, chain);
            logprob = 0;
            
            gammaA(gamma(rep, :, chain)==0) = rand(1, sum(gamma(rep, :, chain)==0)) < zetaAS(gamma(rep, :, chain)==0);
            newgamma(gammaA==1) = 1;
            gammaD(gamma(rep, :, chain)==1) = rand(1, sum(gamma(rep, :, chain)==1)) < zetaDS(gamma(rep, :, chain)==1);
            newgamma(gammaD==1) = 0;
            temp = (gamma(rep, :, chain)==0) .* (newgamma==1);
            logprob = logprob - sum(log(zetaAS(temp==1)));
            temp = (gamma(rep, :, chain)==0) .* (newgamma==0);
            logprob = logprob - sum(log(1 - zetaAS(temp==1)));
            temp = (gamma(rep, :, chain)==1) .* (newgamma==0);
            logprob = logprob - sum(log(zetaDS(temp==1)));
            temp = (gamma(rep, :, chain)==1) .* (newgamma==1);
            logprob = logprob - sum(log(1 - zetaDS(temp==1)));
            temp = (newgamma==0) .* (gamma(rep, :, chain)==1);
            logprob = logprob + sum(log(zetaAS(temp==1)));
            temp = (newgamma==0) .* (gamma(rep, :, chain)==0);
            logprob = logprob + sum(log(1 - zetaAS(temp==1)));
            temp = (newgamma==1) .* (gamma(rep, :, chain)==0);
            logprob = logprob + sum(log(zetaDS(temp==1)));
            temp = (newgamma==1) .* (gamma(rep, :, chain)==1);
            logprob = logprob + sum(log(1 - zetaDS(temp==1)));
            change = sum(gammaA) + sum(gammaD);
            
            if ( change == 0 )
                newloglike = loglike(rep, chain);
            else
                datastar = [ones(n, 1) data_fixed data(:, newgamma==1)];
                if ( gprior == 1 )
                    n0star = zeros(sum(newgamma) + pfixed + 1);
                    n0star((2 + pfixed):end, (2 + pfixed):sum(newgamma)) = 1 / g(rep, chain)  * datastar(:, (2 + pfixed):end)' * datastar(:, (2 + pfixed):end);
                else
                    n0star = 1 / g(rep, chain) * eye(sum(newgamma) + pfixed + 1);
                    n0star(1:(pfixed+1), 1:(pfixed+1)) = 0;
                end
                newC = inv(datastar' * datastar + n0star);
                
                XTy = [sum(target); XTy_fixed; XTy_all(newgamma==1)];
                
                newloglike = - 0.5 * sum(newgamma) * log(g(rep, chain)) - 0.5 * log(det(datastar' * datastar + n0star));
                newloglike = newloglike - 0.5 * n * log(target' * target - XTy' * newC * XTy);
            end
            
            logaccept = heat(chain1) * (newloglike - loglike(rep, chain));
            if ( fixed == 1 )
                logaccept = logaccept + sum(newgamma) * log(w(rep, chain)) + (p - sum(newgamma)) * log(1 - w(rep, chain));
                logaccept = logaccept - sum(gamma(rep, :, chain)) * log(w(rep, chain)) - (p - sum(gamma(rep, :, chain))) * log(1 - w(rep, chain));
            else
                logaccept = logaccept + gammaln(wa + sum(newgamma)) + gammaln(wb + p - sum(newgamma));
                logaccept = logaccept - gammaln(wa + sum(gamma(rep, :, chain))) - gammaln(wb + p - sum(gamma(rep, :, chain)));
            end
            
            logaccept = logaccept + logprob;
            
            accept = 1;
            if ( (isnan(logaccept) == 1) || (isinf(logaccept) == 1) )
                accept = 0;
            elseif ( logaccept < 0 )
                accept = exp(logaccept);
            end
            
            if ( change ~= 0 )
                if ( rand < accept )
                    gamma(rep, :, chain) = newgamma;
                    loglike(rep, chain) = newloglike;
                    C{rep, chain} = newC;
                end
            end
            
            totalaccept(chain1) = totalaccept(chain1) + (change~=0)*accept;
            totalchange(chain1) = totalchange(chain1) + change;
            totalcount(chain1) = totalcount(chain1) + 1;
            
            if ( (adap_type == 1) || ((adap_type==0) && (it < burnin)) )
                logitzetaAS(chain1, :) = logitzetaAS(chain1, :) + 2 / it^0.55 * (change~=0) .* (gammaA * (accept > tauU) + gammaD * (accept > tauL) - gammaA * (accept < tauU));
                logitzetaDS(chain1, :) = logitzetaDS(chain1, :) + 2 / it^0.55 * (change~=0) .* (gammaD * (accept > tauU) + gammaA * (accept > tauL) - gammaD * (accept < tauU));
            end
            
            
            if ( updateg == 1 )
                newg = g(rep, chain) * exp(exp(loggsd(chain1)) * randn);
                
                datastar = [ones(n, 1) data_fixed data(:, gamma(rep, :, chain)==1)];
                if ( gprior == 1 )
                    n0star = zeros(sum(gamma(rep, :, chain)) + size(data_fixed, 2));
                    n0star(1:(sum(gamma(rep, :, chain)) + size(data_fixed, 2)), 2:(sum(gamma(rep, :, chain)) + size(data_fixed, 2))) = 1 / newg * datastar(:, 2:end)' * datastar(:, 2:end);
                else
                    n0star = 1 / newg * eye(sum(gamma(rep, :, chain)) + size(data_fixed, 2) + 1);
                    n0star(1:(1+size(data_fixed, 2)), 1:(1+size(data_fixed, 2))) = 0;
                end
                newC = inv(datastar' * datastar + n0star);
                XTy = [sum(target); XTy_fixed; XTy_all(gamma(rep, :, chain)==1)];
                
                newloglike = - 0.5 * sum(gamma(rep, :, chain)) * log(newg);
                newloglike = newloglike - 0.5 * log(det(datastar' * datastar + n0star));
                newloglike = newloglike - (0.5 * n + sigmasqalpha) * log(sigmasqbeta + 0.5 * (target' * target - XTy' * newC * XTy));
                
                logaccept = heat(chain1) * (newloglike - loglike(rep, chain));
                logaccept = logaccept + log(newg) - 2 * log(1 + newg);
                logaccept = logaccept - log(g(rep, chain)) + 2 * log(1 + g(rep, chain));
                
                accept = 1;
                if ( (isnan(logaccept) == 1) || (isinf(logaccept) == 1) )
                    accept = 0;
                elseif ( logaccept < 0 )
                    accept = exp(logaccept);
                end
                
                if ( rand < accept )
                    g(rep, chain) = newg;
                    loglike(rep, chain) = newloglike;
                    C{rep, chain} = newC;
                end
                
                gaccept(chain1) = gaccept(chain1) + accept;
                gcount(chain1) = gcount(chain1) + 1;
                
                loggsd(chain1) = loggsd(chain1) + 1 / it^0.55 * (accept - 0.234);
            end
        end
    end

    if ( length(heat) > 1 )
        % Swap move
        for rep = 1:numbofreps
            check = 1;
            while ( check == 1 )
                chain1 = ceil(rand * length(heat));
                check = (order(rep, chain1) == length(heat));
            end
            chain2 = find(order(rep, :) == order(rep, chain1) + 1);
            
            loglike1 = loglike(rep, chain1);
            loglike2 = loglike(rep, chain2);
            
            logaccept = heat(order(rep, chain1)) * loglike2 + heat(order(rep, chain2)) * loglike1;
            logaccept = logaccept - heat(order(rep, chain1)) * loglike1 - heat(order(rep, chain2)) * loglike2;
            
            accept = 1;
            if ( logaccept  < 0 )
                accept = exp(logaccept);
            end
            totalaccept2(order(rep, chain1)) = totalaccept2(order(rep, chain1)) + accept;
            totalcount2(order(rep, chain1)) = totalcount2(order(rep, chain1)) + 1;
            
            rhostar(order(rep, chain1)) = rhostar(order(rep, chain1)) + 1 / it^0.55 * (accept - 0.234);
            if ( rhostar(order(rep, chain1)) > 4 )
                rhostar(order(rep, chain1)) = 4;
            end
            
            for j = 1:(length(heat)-1)
                heat(j+1) = heat(j) * exp(- exp(rhostar(j)));
            end
            
            if ( rand < accept )
                order(rep, chain1) = order(rep, chain1) + 1;
                order(rep, chain2) = order(rep, chain2) - 1;
            end
        end
    end
    
    if ( (it > burnin) && (mod(it - burnin, thin) == 0) )
        
        for rep = 1:numbofreps
            top_chain = find(order(rep, :) == 1);
            
            if ( RB == 1 )
                
                datastar = [ones(n, 1) data(:, gamma(rep, :, top_chain)==1)];
                if ( gprior == 1 )
                    n0star = zeros(1 + pfixed + sum(gamma(rep, :, top_chain)));
                    n0star((2+pfixed):end, (2+pfixed):end) = 1 / g(rep, chain)  * datastar(:, (2+pfixed):end)' * datastar(:, (2+pfixed):end);
                else
                    n0star = 1 / g(rep, chain) * eye(sum(gamma(rep, :, top_chain)) + pfixed + 1);
                    n0star(1:(pfixed+1), 1:(pfixed+1)) = 0;
                end
                
                XTy = [sum(target); XTy_fixed; XTy_all(gamma(rep, :, top_chain)==1)];
                
                inner1 = XTy' * C{rep, top_chain} * XTy;
                
                oldloglike2 = 0;
                oldloglike2 = oldloglike2 - 0.5 * n * log(target' * target - inner1);
                
                zstar = find(gamma(rep, :, top_chain) == 1 );
                
                
                XTx_all = datastar' * data;
                XTy_all = data' * target;
                
                D = zeros(1, p);
                newloglike2 = zeros(1, p);
                
                Astar = XTy_all .* (XTx_all' * C{rep, top_chain} * XTy);
                Cstar = XTy_all .* XTy_all;
                Gstar = XTy' * C{rep, top_chain} * XTx_all;
                
                Bstar = zeros(1, p);
                for j = 1:p
                    XTx = XTx_all(:, j);
                    
                    if ( gamma(rep, j, top_chain) == 0 )
                        D(j) = sum(data(:, j).^2) + 1 / g(rep, chain) - XTx' * C{rep, top_chain} * XTx;
                    end
                end
                
                x1 = gamma(rep, :, top_chain)==0;
                Bstar(x1==1) = inner1 + Gstar(x1==1) .* Gstar(x1==1) ./ D(x1==1);
                Bstar(x1==1) = Bstar(x1==1) - 2 * Astar(x1==1)' ./ D(x1==1);
                Bstar(x1==1) = Bstar(x1==1) + Cstar(x1==1)' ./ D(x1==1);
                newloglike2(x1==1) = - 0.5 * n * log(target' * target - Bstar(x1==1));
                
                for j = 1:p
                    XTx = XTx_all(:, j);
                    
                    if ( gamma(rep, j, top_chain) == 1 )
                        pos = find(zstar==j) + 1;
                        Fstar = C{rep, top_chain}([1:(pos-1) (pos+1):end], [1:(pos-1) (pos+1):end]);
                        d3 = C{rep, top_chain}(pos, pos);
                        u3 = - C{rep, top_chain}([1:(pos-1) (pos+1):end], pos);
                        u2 = u3 / d3;
                        inv2 = Fstar - d3 * u2 * u2';
                        
                        D(j) = sum(data(:, j).^2) + 1 / g(rep, chain) - XTx([1:(pos-1) (pos+1):end], 1)' * inv2 * XTx([1:(pos-1) (pos+1):end], 1);
                        
                        newXTy = [XTy(1:(pos-1), 1); XTy((pos+1):end, 1)];
                        newloglike2(j) = - 0.5 * n * log(target' * target - newXTy' * inv2 * newXTy);
                    end
                end
                
                newloglike2 = newloglike2 - (2 * (gamma(rep, :, top_chain)==0) - 1) .* (0.5 * log(g(rep, chain)) + 0.5 * log(D));
                diff = (2 * (gamma(rep, :, top_chain)==0) - 1) .* (newloglike2 - oldloglike2);
                
                BF = zeros(1, p);
                if ( fixed == 1 )
                    x1 = (diff < 0);
                    if ( sum(x1) > 0 )
                        BF(x1==1) = w(rep, top_chain) * exp(diff(x1==1)) ./ (w(rep, top_chain) * exp(diff(x1==1)) + 1 - w(rep, top_chain));
                    end
                    
                    x1 = (diff >= 0);
                    if ( sum(x1) > 0 )
                        BF(x1==1) = w(rep, top_chain) ./ (w(rep, top_chain) + (1 - w(rep, top_chain)) * exp(- diff(x1==1)));
                    end
                else
                    wstar = (wa + sum(gamma(rep, :, top_chain))) / (wa + wb + p);
                    x1 = (diff < 0);
                    if ( sum(x1) > 0 )
                        BF(x1==1) = wstar * exp(diff(x1==1)) ./ (wstar * exp(diff(x1==1)) + 1 - wstar);
                    end
                    
                    x1 = (diff >= 0);
                    if ( sum(x1) > 0 )
                        BF(x1==1) = wstar ./ (wstar + (1 - wstar) * exp(- diff(x1==1)));
                    end
                end
                                               
                sumgamma = sumgamma + BF;
                sumgamma2 = sumgamma2 + gamma(rep, :, top_chain);
            else
                sumgamma = sumgamma + gamma(rep, :, top_chain);
                sumgamma2 = sumgamma2 + gamma(rep, :, top_chain);
            end
            
            if ( fixed == 1 )
                holdloglike((it - burnin) / thin, rep) = loglike(rep, top_chain) + sum(gamma(rep, :, top_chain)) * log(w(rep, chain)) + sum(1-gamma(rep, :, top_chain)) * log(1 - w(rep, chain));
            else
                holdloglike((it - burnin) / thin, rep) = loglike(rep, top_chain) + gammaln(wa + sum(gamma(rep, :, top_chain))) + gammaln(wb + p - sum(gamma(rep, :, top_chain))) - gammaln(wa + wb + p);
            end
            holdmodelsize((it - burnin) / thin, rep) = sum(gamma(rep, :, top_chain));
            holdaccept((it - burnin) / thin) = totalaccept(1) / totalcount(1);
            if ( mode == 2 )
                holdgamma(rep, (it - burnin) / thin, :) = gamma(rep, :, top_chain);
            end
        end
    end
end

max(sumgamma)
sumgamma = sumgamma / (numbofits * numbofreps);
sumgamma2 = sumgamma2 / (numbofits * numbofreps);

zetaAS = zeros(numbofchains, p);
zetaDS = zeros(numbofchains, p);

for chain1 = 1:numbofchains
    check1 = logitzetaAS(chain1, :)<0;
    check2 = logitzetaDS(chain1, :)<0;
    zetaAS(check1==1) = (logita + logitb * exp(logitzetaAS(chain1, check1==1))) ./ (1 + exp(logitzetaAS(chain1, check1==1)));
    zetaDS(check2==1) = (logita + logitb * exp(logitzetaDS(chain1, check2==1))) ./ (1 + exp(logitzetaDS(chain1, check2==1)));
    zetaAS(check1==0) = (logita * exp(- logitzetaAS(chain1, check1==0)) + logitb) ./ (exp(- logitzetaAS(chain1, check1==0)) + 1);
    zetaDS(check2==0) = (logita * exp(- logitzetaDS(chain1, check2==0)) + logitb) ./ (exp(- logitzetaDS(chain1, check2==0)) + 1);
end
    
accept2 = totalaccept2./totalcount2;

output = struct('prob_inclusion', sumgamma, 'prob_inclusion2', sumgamma2, 'logpost', holdloglike, 'modelsize', holdmodelsize, 'accept', holdaccept, 'gamma', holdgamma, 'zetaAS', zetaAS, 'zetaDS', zetaDS, 'accept2', accept2, 'heat', heat);