function [output] = ASI_sampler(data, target, g, gprior, mode, RB_adap, RB, hparam, tau, nu, burnin, numbofits, thin, numbofreps, heat, adap_type)

rhostar = zeros(1, length(heat) - 1);
for i = 1:(length(heat)-1)
    rhostar(i) = log(log(heat(i)/heat(i+1)));
end
order = zeros(numbofreps, length(heat));
for rep = 1:numbofreps
    order(rep, :) = 1:length(heat);
end

[n, p] = size(data);

numbofchains = length(heat);

sigmasqalpha = 4 / 2;
sigmasqbeta = 4 / 2;

beta_sat = (data' * data) \ (data' * target);
RSS = sum((target - data * beta_sat).^2);
sigmasqhat1 = RSS / size(data, 1);
g = 10 / sigmasqhat1;

if ( length(hparam) == 1 )
    fixed = 1;
    w = hparam * ones(numbofreps, numbofchains);
    wstar = hparam;
else
    fixed = 0;
    wa = hparam(1);
    wb = hparam(2);
    wstar = wa / (wa + wb);
end

logita = 0.1 / p;
logitb = 1 - 0.1 / p;

XTy_all = data' * target;

loglike = zeros(numbofreps, numbofchains);

C = cell(numbofreps, numbofchains);
gamma = zeros(numbofreps, p, numbofchains);
for chain = 1:numbofchains
    for rep = 1:numbofreps
        check = 0;
        while ( check == 0 )
            gamma(rep, :, chain) = rand(1, p) < wstar;
            
            datastar = [ones(n, 1) data(:, gamma(rep, :, chain)==1)];
            if ( gprior == 1 )
                n0star = zeros(sum(gamma(rep, :, chain)));
                n0star(2:sum(gamma(rep, :, chain)), 2:sum(gamma(rep, :, chain))) = 1 / g  * datastar(:, 2:end)' * datastar(:, 2:end);
            else
                n0star = 1 / g * eye(sum(gamma(rep, :, chain)) + 1);
                n0star(1, 1) = 0;
            end
            C{rep, chain} = inv(datastar' * datastar + n0star);
            XTy = [sum(target); XTy_all(gamma(rep, :, chain)==1)];
            
            loglike(rep, chain) = - 0.5 * sum(gamma(rep, :, chain)) * log(g) - 0.5 * log(det(datastar' * datastar + n0star));
            loglike(rep, chain) = loglike(rep, chain) - (0.5 * n + sigmasqalpha) * log(sigmasqbeta + 0.5 * target' * target - 0.5 * XTy' * C{rep, chain} * XTy);
            
            if ( isreal(loglike(rep, chain)) == 1 )
                check = 1;
            end
        end
    end
end

zetahat = nu / (wstar * p);
if ( zetahat > 1 )
    zetahat = 0.1;
end
logitzeta0 = (log(zetahat - logita) - log(logitb - zetahat)) * ones(1, numbofchains);

totalaccept = zeros(1, numbofchains);
totalcount = zeros(1, numbofchains);
totalchange = zeros(1, numbofchains);
totalchange2 = zeros(1, numbofchains);

totalaccept2 = zeros(1, numbofchains - 1);
totalcount2 = zeros(1, numbofchains - 1);

sumgamma = zeros(1, p);
sumgamma2 = zeros(1, p);
sumgamma3 = zeros(numbofchains, p);
count3 = zeros(numbofchains, 1);
holdmodelsize = zeros(numbofits, numbofreps);
holdloglike = zeros(numbofits, numbofreps);
holdaccept = zeros(numbofits, 1);
if ( mode == 2 )
    holdgamma = zeros(numbofreps, numbofits, p);
else
    holdgamma = [];
end
for it = 1:(burnin+numbofits*thin)
    
    %     if ( mod(it, 100) == 0 )
    %         disp(['it = ' num2str(it)]);
    %         disp(['numbofreps = ' num2str(numbofreps)]);
    %         disp(['logitzeta0 = ' num2str(logitzeta0(chain1))]);
    %         disp(['accept = ' num2str(totalaccept./totalcount)]);
    %         disp(['accept* = ' num2str(totalaccept./totalchange2)]);
    %         disp(['tau = ' num2str(tau)]);
    %         disp(['change = ' num2str(totalchange./totalcount)]);
    %         disp(num2str(heat));
    %         disp(num2str(totalaccept2./totalcount2));
    %         disp(' ');
    %     end
    
    
    for chain = 1:numbofchains
        for rep = 1:numbofreps
            
            chain1 = order(rep, chain);

            if ( isreal(logitzeta0(chain1)) == 0 )
                loglike(rep, chain)
                logitzeta0(chain1)
                stop;
            end
            
            if ( logitzeta0(chain1) < 0 )
                zeta = (logita + logitb * exp(logitzeta0(chain1))) ./ (1 + exp(logitzeta0(chain1)));
            else
                zeta = (logita * exp(- logitzeta0(chain1)) + logitb) ./ (exp(- logitzeta0(chain1)) + 1);
            end
            probstar = sumgamma3(chain1, :) / count3(chain1);
            probstar = 0.0001 + (1 - 0.0002) * probstar;
            
            p1 = probstar;
            p2 = 1 - probstar;
            
            zetaAS = p1 .* zeta .* min(1./p1, 1./p2);
            zetaDS = p2 .* zeta .* min(1./p1, 1./p2);
            
            gammaA = zeros(1, p);
            gammaD = zeros(1, p);
            newgamma = gamma(rep, :, chain);
            logprob = 0;
            
            gammaA(gamma(rep, :, chain)==0) = rand(1, sum(gamma(rep, :, chain)==0)) < zetaAS(gamma(rep, :, chain)==0);
            newgamma(gammaA==1) = 1;
            gammaD(gamma(rep, :, chain)==1) = rand(1, sum(gamma(rep, :, chain)==1)) < zetaDS(gamma(rep, :, chain)==1);
            newgamma(gammaD==1) = 0;
            temp = (gamma(rep, :, chain)==0) .* (newgamma==1);
            logprob = logprob - sum(log(zetaAS(temp==1)));
            temp = (gamma(rep, :, chain)==0) .* (newgamma==0);
            logprob = logprob - sum(log(1 - zetaAS(temp==1)));
            temp = (gamma(rep, :, chain)==1) .* (newgamma==0);
            logprob = logprob - sum(log(zetaDS(temp==1)));
            temp = (gamma(rep, :, chain)==1) .* (newgamma==1);
            logprob = logprob - sum(log(1 - zetaDS(temp==1)));
            temp = (newgamma==0) .* (gamma(rep, :, chain)==1);
            logprob = logprob + sum(log(zetaAS(temp==1)));
            temp = (newgamma==0) .* (gamma(rep, :, chain)==0);
            logprob = logprob + sum(log(1 - zetaAS(temp==1)));
            temp = (newgamma==1) .* (gamma(rep, :, chain)==0);
            logprob = logprob + sum(log(zetaDS(temp==1)));
            temp = (newgamma==1) .* (gamma(rep, :, chain)==1);
            logprob = logprob + sum(log(1 - zetaDS(temp==1)));
            change = sum(gammaA) + sum(gammaD);
            
            if ( change == 0 )
                newloglike = loglike(rep, chain);
            else
                datastar = [ones(n, 1) data(:, newgamma==1)];
                if ( gprior == 1 )
                    n0star = zeros(sum(newgamma));
                    n0star(2:sum(newgamma), 2:sum(newgamma)) = 1 / g  * datastar(:, 2:end)' * datastar(:, 2:end);
                else
                    n0star = 1 / g * eye(sum(newgamma) + 1);
                    n0star(1, 1) = 0;
                end
                newC = inv(datastar' * datastar + n0star);
                
                XTy = [sum(target); XTy_all(newgamma==1)];
                
                newloglike = - 0.5 * sum(newgamma) * log(g) - 0.5 * log(det(datastar' * datastar + n0star));
                newloglike = newloglike - (0.5 * n + sigmasqalpha) * log(sigmasqbeta + 0.5 * target' * target - 0.5 * XTy' * newC * XTy);
            end
            
            logaccept = heat(chain1) * (newloglike - loglike(rep, chain));
            if ( fixed == 1 )
                logaccept = logaccept + sum(newgamma) * log(w(rep, chain)) + (p - sum(newgamma)) * log(1 - w(rep, chain));
                logaccept = logaccept - sum(gamma(rep, :, chain)) * log(w(rep, chain)) - (p - sum(gamma(rep, :, chain))) * log(1 - w(rep, chain));
            else
                logaccept = logaccept + gammaln(wa + sum(newgamma)) + gammaln(wb + p - sum(newgamma));
                logaccept = logaccept - gammaln(wa + sum(gamma(rep, :, chain))) - gammaln(wb + p - sum(gamma(rep, :, chain)));
            end
            
            logaccept = logaccept + logprob;
            
            accept = 1;
            if ( (isnan(logaccept) == 1) || (isinf(logaccept) == 1) || (isreal(logaccept) == 0) )
                accept = 0;
            elseif ( logaccept < 0 )
                accept = exp(logaccept);
            end
            
            if ( change ~= 0 )
                if ( rand < accept )
                    gamma(rep, :, chain) = newgamma;
                    loglike(rep, chain) = newloglike;
                    C{rep, chain} = newC;
                end
            end
            
            totalaccept(chain1) = totalaccept(chain1) + (change~=0)*accept;
            totalchange(chain1) = totalchange(chain1) + change;
            totalchange2(chain1) = totalchange2(chain1) + (change~=0);
            totalcount(chain1) = totalcount(chain1) + 1;
            
            if ( (adap_type == 1) || ((adap_type==0) && (it < burnin)) )
                
                logitzeta0(chain1) = logitzeta0(chain1) + 2 / it^0.55 * (change~=0) * (accept - tau);
                
                if ( isreal(logitzeta0(chain1)) == 0 )
                    accept
                    logitzeta0(chain1)
                    stop;
                end
                
                if ( (it > burnin) && (RB_adap == 0) )
                    sumgamma3(chain1, :) = sumgamma3(chain1, :) + gamma(rep, :, chain);
                    count3(chain1) = count3(chain1) + 1;                
                else
                    datastar = [ones(n, 1) data(:, gamma(rep, :, chain)==1)];
                    if ( gprior == 1 )
                        n0star = zeros(sum(gamma(rep, :, chain)));
                        n0star(2:sum(gamma(rep, :, chain)), 2:sum(gamma(rep, :, chain))) = 1 / g  * datastar(:, 2:end)' * datastar(:, 2:end);
                    else
                        n0star = 1 / g * eye(sum(gamma(rep, :, chain)) + 1);
                        n0star(1, 1) = 0;
                    end
                    
                    XTy = [sum(target); XTy_all(gamma(rep, :, chain)==1)];
                    
                    inner1 = XTy' * C{rep, chain} * XTy;
                    
                    oldloglike2 = 0;
                    oldloglike2 = oldloglike2 - (0.5 * n + sigmasqalpha) * log(sigmasqbeta + 0.5 * target' * target - 0.5 * inner1);
                    
                    if ( isreal(oldloglike2) == 0 )
                        stop;
                    end
                    
                    zstar = find(gamma(rep, :, chain) == 1 );
                    
                    XTx_all = datastar' * data;
                    XTy_all = data' * target;
                    
                    D = zeros(1, p);
                    newloglike2 = zeros(1, p);
                    
                    Astar = XTy_all .* (XTx_all' * C{rep, chain} * XTy);
                    Cstar = XTy_all .* XTy_all;
                    Gstar = XTy' * C{rep, chain} * XTx_all;
                    
                    Bstar = zeros(1, p);
                    for j = 1:p
                        XTx = XTx_all(:, j);
                        
                        if ( gamma(rep, j, chain) == 0 )
                            D(j) = sum(data(:, j).^2) + 1 / g - XTx' * C{rep, chain} * XTx;
                        end
                    end
                    
                    x1 = gamma(rep, :, chain)==0;
                    Bstar(x1==1) = inner1 + Gstar(x1==1) .* Gstar(x1==1) ./ D(x1==1);
                    Bstar(x1==1) = Bstar(x1==1) - 2 * Astar(x1==1)' ./ D(x1==1);
                    Bstar(x1==1) = Bstar(x1==1) + Cstar(x1==1)' ./ D(x1==1);
                    newloglike2(x1==1) = - (0.5 * n + sigmasqalpha) * log(sigmasqbeta + 0.5 * target' * target - 0.5 * Bstar(x1==1));
                    
                    if ( isreal(newloglike2) == 0 )
                        stop;
                    end

                    
                    for j = 1:p
                        XTx = XTx_all(:, j);
                        
                        if ( gamma(rep, j, chain) == 1 )
                            pos = find(zstar==j) + 1;
                            Fstar = C{rep, chain}([1:(pos-1) (pos+1):end], [1:(pos-1) (pos+1):end]);
                            d3 = C{rep, chain}(pos, pos);
                            u3 = - C{rep, chain}([1:(pos-1) (pos+1):end], pos);
                            %                            u2 = u3 / d3;
                            %                            inv2 = Fstar - d3 * u2 * u2';
                            inv2 = Fstar - u3 * u3' / d3;
                            
                            D(j) = sum(data(:, j).^2) + 1 / g - XTx([1:(pos-1) (pos+1):end], 1)' * inv2 * XTx([1:(pos-1) (pos+1):end], 1);
                            
                            newXTy = [XTy(1:(pos-1), 1); XTy((pos+1):end, 1)];
                            newloglike2(j) = - (0.5 * n + sigmasqalpha) * log(sigmasqbeta + 0.5 * target' * target - 0.5 * newXTy' * inv2 * newXTy);
                        end
                    end
                    
                    if ( isreal(oldloglike2) == 0 )
                        stop;
                    end

                    if ( isreal(newloglike2) == 0 )
                        stop;
                    end

                  
                    
                    newloglike2 = newloglike2 - (2 * (gamma(rep, :, chain)==0) - 1) .* (0.5 * log(g) + 0.5 * log(D));

                    if ( isreal(newloglike2) == 0 )
                        g
                        D
                        stop;
                    end

                    
                    diff = heat(chain1) * (2 * (gamma(rep, :, chain)==0) - 1) .* (newloglike2 - oldloglike2);
                    
                    if ( isreal(diff) == 0 )
                        stop;
                    end
                    
                    BF = zeros(1, p);
                    if ( fixed == 1 )
                        x1 = (diff < 0);
                        if ( sum(x1) > 0 )
                            BF(x1==1) = w(rep, chain) * exp(diff(x1==1)) ./ (w(rep, chain) * exp(diff(x1==1)) + 1 - w(rep, chain));
                        end
                        
                        x1 = (diff >= 0);
                        if ( sum(x1) > 0 )
                            BF(x1==1) = w(rep, chain) ./ (w(rep, chain) + (1 - w(rep, chain)) * exp(- diff(x1==1)));
                        end
                    else
                        wstar = (wa + sum(gamma(rep, :, chain))) / (wa + wb + p);
                        x1 = (diff < 0);
                        if ( sum(x1) > 0 )
                            BF(x1==1) = wstar * exp(diff(x1==1)) ./ (wstar * exp(diff(x1==1)) + 1 - wstar);
                        end
                        
                        x1 = (diff >= 0);
                        if ( sum(x1) > 0 )
                            BF(x1==1) = wstar ./ (wstar + (1 - wstar) * exp(- diff(x1==1)));
                        end
                    end
                    
                    if ( isreal(BF) == 0 )
                        stop;
                    end
                    
                    sumgamma3(chain1, :) = sumgamma3(chain1, :) + BF;
                    count3(chain1) = count3(chain1) + 1;
                end
                
                if ( logitzeta0(chain1) < 0 )
                    zeta = (logita + logitb * exp(logitzeta0(chain1))) ./ (1 + exp(logitzeta0(chain1)));
                else
                    zeta = (logita * exp(- logitzeta0(chain1)) + logitb) ./ (exp(- logitzeta0(chain1)) + 1);
                end
                probstar = sumgamma3(chain1, :) / count3(chain1);
                
                zetaAS = probstar .* zeta .* min(1./probstar, 1./(1 - probstar));
                zetaDS = (1 - probstar) .* zeta .* min(1./probstar, 1./(1 - probstar));
                
                expec_change = sum(zetaAS .* (1 - probstar)) + sum(zetaDS .* probstar);
                if ( expec_change < 1 )
                    logitzeta0(chain1) = logitzeta0(chain1) - log(expec_change);
                end
                
                if ( logitzeta0(chain1) < -10 )
                    logitzeta0(chain1) = - 10;
                end
                if ( logitzeta0(chain1) > 10 )
                    logitzeta0(chain1) = 10;
                end
                
                if ( isreal(logitzeta0(chain1)) == 0 )
                    expec_change
                    logitzeta0(chain1)
                    stop;
                end
                
                
            end
        end
    end
    
    if ( length(heat) > 1 )
        % Swap move
        for rep = 1:numbofreps
            check = 1;
            while ( check == 1 )
                chain1 = ceil(rand * length(heat));
                check = (order(rep, chain1) == length(heat));
            end
            chain2 = find(order(rep, :) == order(rep, chain1) + 1);
            
            loglike1 = loglike(rep, chain1);
            loglike2 = loglike(rep, chain2);
            
            logaccept = heat(order(rep, chain1)) * loglike2 + heat(order(rep, chain2)) * loglike1 - heat(order(rep, chain1)) * loglike1 - heat(order(rep, chain2)) * loglike2;
            
            accept = 1;
            if ( logaccept  < 0 )
                accept = exp(logaccept);
            end
            totalaccept2(order(rep, chain1)) = totalaccept2(order(rep, chain1)) + accept;
            totalcount2(order(rep, chain1)) = totalcount2(order(rep, chain1)) + 1;
            
            rhostar(order(rep, chain1)) = rhostar(order(rep, chain1)) + 1 / it^0.55 * (accept - 0.234);
            if ( rhostar(order(rep, chain1)) > 4 )
                rhostar(order(rep, chain1)) = 4;
            end
            
            for j = 1:(length(heat)-1)
                heat(j+1) = heat(j) * exp(- exp(rhostar(j)));
            end
            
            if ( rand < accept )
                order(rep, chain1) = order(rep, chain1) + 1;
                order(rep, chain2) = order(rep, chain2) - 1;
            end
        end
    end
    
    if ( (it > burnin) && (mod(it - burnin, thin) == 0) )
        
        for rep = 1:numbofreps
            top_chain = find(order(rep, :) == 1);
            
            if ( RB == 1 )
                
                datastar = [ones(n, 1) data(:, gamma(rep, :, top_chain)==1)];
                if ( gprior == 1 )
                    n0star = zeros(sum(gamma(rep, :, top_chain)));
                    n0star(2:sum(gamma(rep, :, top_chain)), 2:sum(gamma(rep, :, top_chain))) = 1 / g  * datastar(:, 2:end)' * datastar(:, 2:end);
                else
                    n0star = 1 / g * eye(sum(gamma(rep, :, top_chain)) + 1);
                    n0star(1, 1) = 0;
                end
                
                XTy = [sum(target); XTy_all(gamma(rep, :, top_chain)==1)];
                
                inner1 = XTy' * C{rep, top_chain} * XTy;
                
                oldloglike2 = 0;
                oldloglike2 = oldloglike2 - (0.5 * n + sigmasqalpha) * log(sigmasqbeta + 0.5 * target' * target - 0.5 * inner1);
                
                zstar = find(gamma(rep, :, top_chain) == 1 );                
                
                XTx_all = datastar' * data;
                XTy_all = data' * target;
                
                D = zeros(1, p);
                newloglike2 = zeros(1, p);
                
                Astar = XTy_all .* (XTx_all' * C{rep, top_chain} * XTy);
                Cstar = XTy_all .* XTy_all;
                Gstar = XTy' * C{rep, top_chain} * XTx_all;
                
                Bstar = zeros(1, p);
                for j = 1:p
                    XTx = XTx_all(:, j);
                    
                    if ( gamma(rep, j, top_chain) == 0 )
                        D(j) = sum(data(:, j).^2) + 1 / g - XTx' * C{rep, top_chain} * XTx;
                    end
                end
                
                x1 = gamma(rep, :, top_chain)==0;
                Bstar(x1==1) = inner1 + Gstar(x1==1) .* Gstar(x1==1) ./ D(x1==1);
                Bstar(x1==1) = Bstar(x1==1) - 2 * Astar(x1==1)' ./ D(x1==1);
                Bstar(x1==1) = Bstar(x1==1) + Cstar(x1==1)' ./ D(x1==1);
                newloglike2(x1==1) = - (0.5 * n + sigmasqalpha) * log(sigmasqbeta + 0.5 * target' * target - 0.5 * Bstar(x1==1));
                
                for j = 1:p
                    XTx = XTx_all(:, j);
                    
                    if ( gamma(rep, j, top_chain) == 1 )
                        pos = find(zstar==j) + 1;
                        Fstar = C{rep, top_chain}([1:(pos-1) (pos+1):end], [1:(pos-1) (pos+1):end]);
                        d3 = C{rep, top_chain}(pos, pos);
                        u3 = - C{rep, top_chain}([1:(pos-1) (pos+1):end], pos);
              %          u2 = u3 / d3;
                        %                        inv2 = Fstar - d3 * u2 * u2';
                        inv2 = Fstar - u3 * u3' / d3;
                        
                        D(j) = sum(data(:, j).^2) + 1 / g - XTx([1:(pos-1) (pos+1):end], 1)' * inv2 * XTx([1:(pos-1) (pos+1):end], 1);
                        
                        newXTy = [XTy(1:(pos-1), 1); XTy((pos+1):end, 1)];
                        newloglike2(j) = - (0.5 * n + sigmasqalpha) * log(sigmasqbeta + 0.5 * target' * target - 0.5 * newXTy' * inv2 * newXTy);
                    end
                end
                
                newloglike2 = newloglike2 - (2 * (gamma(rep, :, top_chain)==0) - 1) .* (0.5 * log(g) + 0.5 * log(D));
                diff = (2 * (gamma(rep, :, top_chain)==0) - 1) .* (newloglike2 - oldloglike2);
                
                BF = zeros(1, p);
                if ( fixed == 1 )
                    x1 = (diff < 0);
                    if ( sum(x1) > 0 )
                        BF(x1==1) = w(rep, top_chain) * exp(diff(x1==1)) ./ (w(rep, top_chain) * exp(diff(x1==1)) + 1 - w(rep, top_chain));
                    end
                    
                    x1 = (diff >= 0);
                    if ( sum(x1) > 0 )
                        BF(x1==1) = w(rep, top_chain) ./ (w(rep, top_chain) + (1 - w(rep, top_chain)) * exp(- diff(x1==1)));
                    end
                else
                    wstar = (wa + sum(gamma(rep, :, top_chain)) - gamma(rep, :, top_chain)) / (wa + wb + p - 1);
                    x1 = (diff < 0);
                    if ( sum(x1) > 0 )
                        BF(x1==1) = wstar * exp(diff(x1==1)) ./ (wstar * exp(diff(x1==1)) + 1 - wstar);
                    end
                    
                    x1 = (diff >= 0);
                    if ( sum(x1) > 0 )
                        BF(x1==1) = wstar ./ (wstar + (1 - wstar) * exp(- diff(x1==1)));
                    end
                end
                
                sumgamma = sumgamma + BF;
                sumgamma2 = sumgamma2 + gamma(rep, :, top_chain);
            else
                sumgamma = sumgamma + gamma(rep, :, top_chain);
            end
            
            if ( fixed == 1 )
                holdloglike((it - burnin) / thin, rep) = loglike(rep, top_chain) + sum(gamma(rep, :, top_chain)) * log(w(rep, chain)) + sum(1-gamma(rep, :, top_chain)) * log(1 - w(rep, chain));
            else
                holdloglike((it - burnin) / thin, rep) = loglike(rep, top_chain) + gammaln(wa + sum(gamma(rep, :, top_chain))) + gammaln(wb + p - sum(gamma(rep, :, top_chain))) - gammaln(wa + wb + p);
            end
            holdmodelsize((it - burnin) / thin, rep) = sum(gamma(rep, :, top_chain));
            holdaccept((it - burnin) / thin) = totalaccept(1) / totalcount(1);
            if ( mode == 2 )
                holdgamma(rep, (it - burnin) / thin, :) = gamma(rep, :, top_chain);
            end
        end
    end
end

max(sumgamma)
sumgamma = sumgamma / (numbofits * numbofreps);
sumgamma2 = sumgamma2 / (numbofits * numbofreps);

zetaAS = zeros(numbofchains, p);
zetaDS = zeros(numbofchains, p);
zeta = zeros(numbofchains);

for chain1 = 1:numbofchains
    
    if ( logitzeta0(chain1) < 0 )
        zeta(chain1) = (logita + logitb * exp(logitzeta0(chain1))) ./ (1 + exp(logitzeta0(chain1)));
    else
        zeta(chain1) = (logita * exp(- logitzeta0(chain1)) + logitb) ./ (exp(- logitzeta0(chain1)) + 1);
    end
    
    probstar = sumgamma3(chain1, :) / count3(chain1);
    
    zetaAS(chain1, :) = probstar .* zeta(chain1) .* min(1./probstar, 1./(1 - probstar));
    zetaDS(chain1, :) = (1 - probstar) .* zeta(chain1) .* min(1./probstar, 1./(1 - probstar));
end

accept2 = totalaccept2./totalcount2;

output = struct('prob_inclusion', sumgamma, 'prob_inclusion2', sumgamma2, 'logpost', holdloglike, 'modelsize', holdmodelsize, 'accept', holdaccept, 'gamma', holdgamma, 'zeta', zeta, 'zetaAS', zetaAS, 'zetaDS', zetaDS, 'accept2', accept2, 'heat', heat);