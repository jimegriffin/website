load 'tecator_short.txt'

tecator1 = reshape(tecator_short', 125, 240)';

data = tecator1(1:172, 1:100);
target = tecator1(1:172, 124);

meandata = mean(data);
for i = 1:100
    data(:, i) = (data(:, i) - meandata(i));
end
target = target - mean(target);



g = 100;
gprior = 0;
mode = 1;
hparam = 5 / 100;
tau = 0.25;
nu = 1;
RB = 1;
adap_type = 1;
num_burn= 100;
num_its = 200;
num_thin = 1;
num_reps = 25;

% [output_IA] = EIA_sampler(data, target, g, gprior, mode, RB, hparam, nu, num_burn, num_its, num_thin, num_reps, 1, adap_type);
% figure(1)
% subplot(2,2,1)
% plot(output_IA.prob_inclusion)
% subplot(2,2,2)
% plot(output_IA.modelsize)
% subplot(2,2,3)
% plot(output_IA.zetaAS)
% subplot(2,2,4)
% plot(output_IA.zetaDS)

RB_adap = 1;

[output_ASI] = ASI_sampler(data, target, g, gprior, mode, RB_adap, RB, hparam, tau, nu, num_burn, num_its, num_thin, num_reps, 1, adap_type);

figure(2)
subplot(2,2,1)
plot(output_ASI.prob_inclusion)
subplot(2,2,2)
plot(output_ASI.modelsize)
subplot(2,2,3)
plot(output_ASI.zetaAS)
subplot(2,2,4)
plot(output_ASI.zetaDS)
